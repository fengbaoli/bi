__author__ = '343715'

class DownLoadFile:
    def __init__(self,ip,username,password,ssh_port,filename):
        self.ip = ip
        self.username = username
        self.password = password
        self.ssh_port = ssh_port
        self.filename = filename
    def downLoadFile(self):
        import paramiko
        t = paramiko.Transport((self.ip,int(self.ssh_port)))
        t.connect(username=self.username, password=self.password)  # ��¼Զ�̷�����
        sftp = paramiko.SFTPClient.from_transport(t)   # sftp����Э��
        src = self.filename
        des = local_path
        sftp.get(src,des)
        t.close()
        return  des

