# -*- coding: utf-8 -*-
from django.conf.urls.defaults import patterns, include, url
# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()
from cms.bi import views
import os,settings
urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'cms.views.home', name='home'),
    # url(r'^cms/', include('cms.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    url(r'^admin/', include(admin.site.urls)),
    url(r'^login/', views.login),
    url(r'^index/', views.index),
    url(r'^logout/', views.logout),
    #静态路径
    url(r'^images/(?P<path>.*)$','django.views.static.serve',{'document_root':os.path.join( settings.STATIC_PATH , 'images' )}) ,
    url(r'^css/(?P<path>.*)$','django.views.static.serve',{'document_root':os.path.join(settings.STATIC_PATH ,'css' )}) ,
    url(r'^js/(?P<path>.*)$','django.views.static.serve',{'document_root':os.path.join(settings.STATIC_PATH ,'js' )}) ,
    url(r'^upload/(?P<path>.*)$','django.views.static.serve',{'document_root':os.path.join(settings.STATIC_PATH ,'upload' )}) ,
    url(r'^usertemplates/(?P<path>.*)','django.views.static.serve',{'document_root':os.path.join(settings.BASE_DIR,'cms/bi/templates/user_manager')}),
    #bi
    url(r'^resource/',views.resource),  
    url(r'^save_resource/',views.save_resource),
    url(r'^edit_resource/',views.edit_resource),
    url(r'^jboss_deploy/',views.jboss_deploy),
    url(r'^manager_index/',views.manager_index),
    url(r'^xml_import_export/',views.xml_import_export),
    url(r'^resource_info/',views.resource_info),
    #jboss log
    url(r'^jboss_log/',views.jboss_log),
    url(r'^jboss_log_search/',views.jboss_log_search),
    url(r'^filedownload/',views.filedownload),
    #知识库
    url(r'^topological_graph/',views.topological_graph),
    #jboss监控
    url(r'^jboss_monitor/',views.jboss_monitor),
    url(r'^jboss_system_search/',views.jboss_system_search),
)  
