__author__ = 'liushuang'
from django.contrib import  admin
from cms.bi.models import  System_user,User_role

admin.site.register(User_role)
class System_user_admin(admin.ModelAdmin):
    list_display = ('username',)
admin.site.register(System_user)
