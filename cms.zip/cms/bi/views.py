# -*- coding: utf-8 -*-
from jboss_log import  JbossLog
from jboss_check import  JbossCheck
from django.shortcuts import  render_to_response
from  django.http import HttpResponse
from django.http import  HttpResponseRedirect
from cms.bi.models import System_user,User_role
from django.db import connection,transaction
from django.contrib.auth.decorators import login_required  
from cms.bi.models  import  ResourceInfo
import MySQLdb
import MySQLdb.cursors
import random,os
import sys,re
reload(sys)
sys.setdefaultencoding("utf-8")

def login(request):
    username = request.POST.get('username',None)
    password = request.POST.get('password',None)
    code = request.POST.get('code',None)
    gencode = request.POST.get('gencode',None)
    if username:
       if "用户名登录" in username:
          return  render_to_response('login.html')
       else:
           ac_list = System_user.objects.filter(username=username)
           for account in ac_list:
               if account.username == username and account.password == password and code == gencode:
                   request.session['username'] = username
                   return  render_to_response('index.html',{'username':username})
               else:
                   return render_to_response('login.html')
    else:
        return render_to_response('login.html')

def logout(request):
    try:
        del request.session['username']
    except KeyError:
        pass
    return  HttpResponseRedirect("/login/")


def index(request):
    return  render_to_response("index.html")
def resource(request):
    sql = "select system_name,deploy_contents,ip_address,ssh_port,op_account,op_password,manager_account,manager_password,remarks,ssh_status from bi_resourceinfo group by ip_address"
    cursor = connection.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    return  render_to_response('resource.html',{'resourceinfo':result})
def edit_resource(request):
    edit_sql = request.POST.get('id', '');
    system_name = request.POST.get('system_name', '');
    deploy_contents = request.POST.get('deploy_contents', '');
    ip_address = request.POST.get('ip_address', '');
    ssh_port = request.POST.get('ssh_port', '');
    op_account = request.POST.get('op_account', '');
    op_password = request.POST.get('op_password', '');
    manager_account = request.POST.get('manager_account', '');
    manager_password = request.POST.get('manager_password', '');
    remarks = request.POST.get('remarks', '')
    flag =request.POST.get('flag', '')
    if edit_sql:
       cursor = connection.cursor()
       cursor.execute(edit_sql)
       sql = "select id,system_name,deploy_contents,ip_address,ssh_port,op_account,op_password,manager_account,manager_password,remarks,Flag from bi_resourceinfo"
       cursor = connection.cursor()
       cursor.execute(sql)
       result  = cursor.fetchall()
       return  render_to_response('edit_resource.html',{'resourceinfo':result})
    if system_name:
       p =  ResourceInfo(system_name=system_name,deploy_contents=deploy_contents,ip_address=ip_address,ssh_port=ssh_port,op_account=op_account,op_password=op_password,manager_account=manager_account,manager_password=manager_password,remarks=remarks,Flag=flag)
       p.save()
       sql = "select id,system_name,deploy_contents,ip_address,ssh_port,op_account,op_password,manager_account,manager_password,remarks,Flag from bi_resourceinfo"
       cursor = connection.cursor()
       cursor.execute(sql)
       result  = cursor.fetchall()
       message = "添加主机成功!"
       return  render_to_response('edit_resource.html',{'resourceinfo':result,'message':message})
    else:
       sql = "select id, system_name,deploy_contents,ip_address,ssh_port,op_account,op_password,manager_account,manager_password,remarks,Flag from bi_resourceinfo"
       cursor = connection.cursor()
       cursor.execute(sql)
       result  = cursor.fetchall()
       return  render_to_response('edit_resource.html',{'resourceinfo':result})
def save_resource(request):
      import_sql = request.POST.get('sql', '')
      if import_sql:
          import_sql_list= import_sql.split("|")
          for single in import_sql_list:
             if not  single:
                pass
             else:
                single_list =single.split(",")
                system_name=single_list[0]
                deploy_contents = single_list[1]
                ip_address=single_list[2]
                ssh_port = single_list[3]
                op_account = single_list[4]
                op_password = single_list[5]
                manager_account = single_list[6]
                manager_password = single_list[7]
                remarks = single_list[8]
                p =  ResourceInfo(system_name=system_name,deploy_contents=deploy_contents,ip_address=ip_address,ssh_port=ssh_port,op_account=op_account,op_password=op_password,manager_account=manager_account,manager_password=manager_password,remarks=remarks)
                p.save()
          sql = "select system_name,deploy_contents,ip_address,ssh_port,op_account,op_password,manager_account,manager_password,remarks,Flag from bi_resourceinfo"
          cursor = connection.cursor()
          cursor.execute(sql)
          result  = cursor.fetchall()
          return  render_to_response('save_resource.html',{'resourceinfo':result})
      else:
          sql = "select system_name,deploy_contents,ip_address,ssh_port,op_account,op_password,manager_account,manager_password,remarks,Flag from bi_resourceinfo"
          cursor = connection.cursor()
          cursor.execute(sql)
          result  = cursor.fetchall()
          return  render_to_response('save_resource.html',{'resourceinfo':result})

def resource_info(request):
    return  render_to_response('resource_info.html',{'ip_address':ip_address})

def jboss_deploy(request):
    return render_to_response('jboss_deploy.html')






def manager_index(request):
     return render_to_response('manager_index.html')






def xml_import_export(request):
    # 获取文件
    Flag = "jboss"
    file_obj = request.FILES.get('your_file', None)
    save_path=os.getcwd()+"/static/upload/"
    if file_obj:
    # 写入文件
       file_name = 'temp_file-%d' % random.randint(0,100000) # 不能使用文件名称，因为存在中文，会引起内部错误
       file_full_path = os.path.join(save_path, file_name)
       dest = open(file_full_path,'wb+')
       dest.write(file_obj.read())
       dest.close()
       #解析xml
       from formatxml import formatXml
       xmlcontents = formatXml().formatxml(file_full_path)
       for resourceinfo in  xmlcontents:
           logfilepath =resourceinfo['Home']+"/"+resourceinfo['Name']+"/log"
           p =  ResourceInfo(system_name=resourceinfo['cluster_name'],deploy_contents=resourceinfo['Name'],ip_address=resourceinfo['Host'],ssh_port=resourceinfo['Port'],op_account=resourceinfo['User'],op_password=resourceinfo['Password'],AcceptCount=resourceinfo['AcceptCount'],JmxPort=resourceinfo['JmxPort'],AppDir=resourceinfo['AppDir'],HttpPort=resourceinfo['HttpPort'],Xmx=resourceinfo['Xmx'],File=resourceinfo['File'],ContextRoot=resourceinfo['ContextRoot'],Xms=resourceinfo['Xms'],Home=resourceinfo['Home'],LogFile=logfilepath,Flag=Flag)
           p.save()
       return render_to_response('xml_import_export.html',{})
    return render_to_response('xml_import_export.html',{})


#各种日志拉取
def jboss_log(request):
    ipaddress =  request.POST.get('ipaddress', '')
    if ipaddress:
      sql = "select op_account,op_password,ssh_port,GROUP_CONCAT(LogFile) from bi_resourceinfo where Flag = 'jboss' and    ip_address=\'%s\'" %(ipaddress)
      cursor = connection.cursor()
      cursor.execute(sql)
      result  = cursor.fetchall()
      for username,password,ssh_port,logspath in result:
        log_info = JbossLog().GetLogInfo(str(ipaddress),username,password,int(ssh_port),str(logspath))
      return  render_to_response('jboss_log.html',{'log_info':log_info})
    else:
      return  render_to_response('jboss_log.html')

def filedownload(request):
    file_name = request.POST.get('filename',None)
    filename = file_name.split("/")[-1]
    ssh_str = request.POST.get('ssh_str',None)
    ip = ssh_str.split("|||")[0]
    username = ssh_str.split("|||")[1]
    password = ssh_str.split("|||")[2]
    ssh_port = ssh_str.split("|||")[3]
    #remote download file
    import shutil
    if os.path.exists(os.getcwd()+"/static/download/"):
       shutil.rmtree(os.getcwd()+"/static/download/")
       os.mkdir(os.getcwd()+"/static/download/")
    else:
       os.mkdir(os.getcwd()+"/static/download/")
    import paramiko
    t = paramiko.Transport((ip,int(ssh_port)))
    t.connect(username=username, password=password)  # 登录远程服务器
    sftp = paramiko.SFTPClient.from_transport(t)   # sftp传输协议
    src =file_name
    des =os.getcwd()+"/static/download/"+filename
    sftp.get(src,des)
    t.close()
    def readFile(des, buf_size=262144):
        #打开日志文件
        f = open(des, "rb")
        #按照缓存大小进行文件加载
        while True:
            log_contents = f.read(buf_size)
            #对文件中的敏感数据进行替换
            replace_log_contents= log_contents.replace("laosiji1@etl","password")
            if replace_log_contents:
                yield replace_log_contents
            else:
                break
        f.close()
    response = HttpResponse(readFile(des), content_type='APPLICATION/OCTET-STREAM')
    response['Content-Disposition'] = 'attachment; filename='+filename.encode('utf-8')
    response['Content-Length'] = os.path.getsize(des)
    return response


def jboss_log_search(request):
    sql = "select ip_address,GROUP_CONCAT(File SEPARATOR '|') from bi_resourceinfo where Flag = 'jboss' group by ip_address"
    cursor = connection.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    return  render_to_response('jboss_log_search.html',{'ipaddress':result})


def topological_graph(request):
    return  render_to_response('topological_graph.html')


#监控
def jboss_monitor(request):
    systemname =  request.POST.get('systemname', '')
    if systemname:
      sql = "select system_name,deploy_contents,concat(\"http://\",ip_address,\":\",HttpPort,\"/\",ContextRoot) as url,ip_address,HttpPort from bi_resourceinfo where system_name=\'%s\'" %(systemname)
      cursor = connection.cursor()
      cursor.execute(sql)
      result  = cursor.fetchall()
      message_list =[]
      for instances in result:
          systemname = instances[0]
          deploy_contents = instances[1]
          url = instances[2]
          ip_address = instances [3]
          HttpPort = instances[4]
          check_status=JbossCheck(url)
          tup=(systemname,deploy_contents,ip_address,HttpPort,check_status)
          message_list.append(tup)
      return  render_to_response('jboss_monitor.html',{'status':message_list})
    else:
      return  render_to_response('jboss_monitor.html')

def jboss_system_search(request):
    sql = "select system_name,GROUP_CONCAT(deploy_contents SEPARATOR '|') as deploy_contents from bi_resourceinfo group by system_name"
    cursor = connection.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    return  render_to_response('jboss_system_search.html',{'system_name':result})

