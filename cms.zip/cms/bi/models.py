# -*- coding: utf-8 -*-

from django.db import models
from django.forms import ModelForm
import django.forms as forms



class User_role(models.Model):
    role_name = models.CharField(max_length=50)
    def __unicode__(self):
        return  u'%s' % (self.role_name)

class UserroleForm(ModelForm):
    class Meta:
        model = User_role 
        fields = '__all__'

class System_user(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    telephone_number = models.CharField(max_length=50)
    user_role= models.ForeignKey(User_role)
    def __unicode__(self):
        return u'%s ' % (self.username)
    class Meta:
        ordering=['username']

class ResourceInfo(models.Model):
    system_name = models.CharField('系统名 cluster_name',max_length=50)
    deploy_contents = models.CharField('部署内容 Name',max_length=50)
    ip_address = models.CharField('IP地址 Host',max_length=50)
    ssh_port = models.CharField('ssh端口',max_length=50)
    op_account = models.CharField('运维账号 User',max_length=50)
    op_password = models.CharField('运维密码 Password',max_length=50)
    manager_account = models.CharField('manager账号 User',max_length=50,null=True)
    manager_password = models.CharField('manager密码 Password',max_length=50,null=True)
    remarks = models.CharField('备注',max_length=250,null=True)
    ssh_status = models.CharField('可登陆状态',max_length=50,default="N/A")
    AcceptCount = models.CharField('可接受连接数',max_length=50,null=True)
    JmxPort= models.CharField('JmxPort',max_length=50,null=True)
    AppDir= models.CharField('包上传路径',max_length=50,null=True)
    HttpPort= models.CharField('可登陆状态',max_length=50,null=True)
    Xmx = models.CharField('Xmx',max_length=50,null=True)
    File = models.CharField('包名',max_length=50,null=True)
    ContextRoot = models.CharField('验证地址',max_length=50,null=True)
    Xms = models.CharField('Xms',max_length=50,null=True)
    Home = models.CharField('jboss安装目录',max_length=50,null=True)
    LogFile = models.CharField('jboss日志路径',max_length=50,null=True)
    Flag = models.CharField('jboss或cognos或etl',max_length=50,null=True)
