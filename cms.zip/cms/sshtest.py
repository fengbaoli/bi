# -*- coding: utf-8 -*-
import MySQLdb
import paramiko


db_host = "localhost"
db_user = "root"
db_password = "root123"
database = "bi_manager"

def ssh_connect(hostname,port,username,password):
    try:
         ssh = paramiko.SSHClient()
         ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
         ssh.connect(hostname,port,username,password,timeout=20)
         message ="ok"
         ssh.close()
    except :
         message="fail"
    return  message

def write_ssh_status(status,id):
    sql = "update bi_resourceinfo set ssh_status=\'%s\' where id =%s" %(status,id)
    db = MySQLdb.connect(db_host,db_user,db_password,database)
    cursor = db.cursor()
    cursor.execute(sql)
    cursor.close()
    db.close()
def update_ssh_status():
    sql = "select id,ip_address,ssh_port,op_account,op_password from bi_resourceinfo"
    db = MySQLdb.connect(db_host,db_user,db_password,database)
    cursor = db.cursor()
    cursor.execute(sql)
    for data in cursor.fetchall():
        status =ssh_connect(data[1],data[2],data[3],data[4])
        write_ssh_status(status,data[0])
    cursor.close()
    db.close()


if __name__ == '__main__':
    update_ssh_status()
