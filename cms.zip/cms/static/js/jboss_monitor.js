/**
 * Created by 343715 on 2016/11/30.
 */
/**
 * Created by 343715 on 2016/11/28.
 */


function openWin_log_ip() {
    var url="/jboss_system_search/";
    var name="ip";
    var iWidth=600;
    var iHeight=300;
    var iTop = (window.screen.height-30-iHeight)/2;
    var iLeft = (window.screen.width-10-iWidth)/2;
    window.open(url,name,'height='+iHeight+',,innerHeight='+iHeight+',width='+iWidth+',innerWidth='+iWidth+',top='+iTop+',left='+iLeft+',toolbar=no,menubar=no,scrollbars=yes,resizeable=no,location=no,status=no');
        }
 function selectedThis_system(obj) {
     var ips = obj.title.split(" ");
     var ip = ips[0];
     window.opener.setValue_system_name(ip);
     window.opener = null;
     window.close();
 }
function setValue_system_name(systemname) {
    var systemname = systemname;
    document.getElementById("systemname").value = systemname;
}


function post(url, params) {
    var temp = document.createElement("form");
    temp.action = url;
    temp.method = "post";
    temp.style.display = "none";
    for (var x in params) {
        var opt = document.createElement("textarea");
        opt.name = x;
        opt.value = params[x];
        temp.appendChild(opt);
    }
    document.body.appendChild(temp);
    temp.submit();
    return temp;
}

function myCheck(){
    for (var i =0 ;i<document.log_ip.elements.length-1;i++)
    {
        if (document.log_ip.elements[i].value ==""){
            alert("系统名为空!");
            document.log_ip.elements[i].focus();
            return false;
        }
    }
    return true
}

