 function method2(tableid) //读取表格中每个单元到EXCEL中
 {
     var curTbl = document.getElementById(tableid);
     var oXL = new ActiveXObject("Excel.Application");
     //创建AX对象excel
     var oWB = oXL.Workbooks.Add();
     //获取workbook对象
     var oSheet = oWB.ActiveSheet;
     //激活当前sheet
     var Lenr = curTbl.rows.length;
     //取得表格行数
     for (i = 0; i < Lenr; i++)
     {
         var Lenc = curTbl.rows(i).cells.length;
         //取得每行的列数
         for (j = 0; j < Lenc; j++)
        {
 
            if(i>=1 && j==5)
			{
			 oSheet.Cells(i + 1, j + 1).value = curTbl.rows[i].cells[5].name;  
            }
			else if(i>=1 && j==7)
			{
              oSheet.Cells(i + 1, j + 1).value = curTbl.rows[i].cells[7].name;
            }
			else
			{
			  oSheet.Cells(i + 1, j + 1).value = curTbl.rows(i).cells(j).innerText;
			}
              

           
         }
     }
     oXL.Visible = true;
     //设置excel可见属性
 }


function ReadExcel() {  
   var tempStr = "";  
   //得到文件路径的值  
   var filePath = document.getElementById("mypath").value;  
   //创建操作EXCEL应用程序的实例  
   var oXL = new ActiveXObject("Excel.application");  
	//打开指定路径的excel文件  
   var oWB = oXL.Workbooks.open(filePath);  
   //操作第一个sheet(从一开始，而非零)  
   oWB.worksheets(1).select();  
   var oSheet = oWB.ActiveSheet;  
   //使用的行数  
   var rows =  oSheet.usedrange.rows.count;   
   try {  
	  for (var i = 2; i <= rows; i++) {  
		 if (oSheet.Cells(i, 2).value == "null" || oSheet.Cells(i, 2).value == "null") break;  
		 var a = oSheet.Cells(i, 2).value.toString() == "N/A" ? "": oSheet.Cells(i, 2).value;
		 //一行一行解析问价内容
		 cell1_index=oSheet.Cells(i, 1).value;
		 cell2_index=oSheet.Cells(i, 2).value;
		 cell3_index=oSheet.Cells(i, 3).value;
		 cell4_index=oSheet.Cells(i, 4).value;
		 cell5_index=oSheet.Cells(i, 5).value;
		 cell6_index=oSheet.Cells(i, 6).value;
		 cell7_index=oSheet.Cells(i, 7).value;
		 cell8_index=oSheet.Cells(i, 8).value;
		 cell9_index=oSheet.Cells(i, 9).value;
		 //如果1-6列出现空值，就报错
		 if (typeof(cell1_index) == "undefined"||typeof(cell2_index) == "undefined"||typeof(cell3_index) == "undefined"||typeof(cell4_index) == "undefined"||typeof(cell5_index) == "undefined"||typeof(cell6_index) == "undefined")
		 { 
		 alert("excel格式不正确存在空值（1-6列）,请检查！");
		 break;
		 }  
		 //如果7-9列出现空值，替换为N/A
		 if (typeof(cell7_index) == "undefined"){
		 cell7_index = "N/A";
		 }
		 if(typeof(cell8_index) == "undefined"){
		 cell8_index = "N/A";
		 }
		 if(typeof(cell9_index) == "undefined"){
		 cell9_index = "N/A";
		 }	
	   tempStr += (cell1_index + "," + cell2_index + ","+ cell3_index + ","+ cell4_index + ","+ cell5_index + ","+ cell6_index + "," + cell7_index + "," + cell8_index +","+ cell9_index + "|");  
	  }  
   } catch(e) {  
	  document.getElementById("txtArea").value = tempStr;  
   }
var turnForm = document.createElement("form");    
document.body.appendChild(turnForm);
turnForm.method = 'post';
turnForm.action = '/save_resource/';
var newElement = document.createElement("input");
newElement.setAttribute("name","sql");
newElement.setAttribute("type","hidden");
newElement.setAttribute("value",tempStr);
turnForm.appendChild(newElement);
turnForm.submit();
//退出操作excel的实例对象  
 oXL.Application.Quit();  
	//手动调用垃圾收集器  
   CollectGarbage();  
} 
