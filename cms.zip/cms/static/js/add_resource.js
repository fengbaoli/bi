function addRow()
{   
    var bodyObj=  document.getElementById('table1');
    if(bodyObj==null) 
    {
        alert("Body of Table not Exist!");
        return;
		
    }

    var rowCount = bodyObj.rows.length;
    var newRow = bodyObj.insertRow(rowCount++);
    newRow.insertCell(0).innerHTML="<input type='text' name='system_name' size=9% />";
    newRow.insertCell(1).innerHTML="<input type='text' name='deploy_contents'  size=9% />";
    newRow.insertCell(2).innerHTML="<input type='text' name='ip_address'  size=9% />";
    newRow.insertCell(3).innerHTML="<input type='text' name='ssh_port'   size=9% />";
    newRow.insertCell(4).innerHTML="<input type='text' name='op_account'  size=9% />";
    newRow.insertCell(5).innerHTML="<input type='password' name='op_password'   size=9% />";
    newRow.insertCell(6).innerHTML="<input type='text' name='manager_account' size=9% />";
    newRow.insertCell(7).innerHTML="<input type='password' name='manager_password' size=9% />";
    newRow.insertCell(8).innerHTML="<input type='text' name='remarks' size=9% />";
    newRow.insertCell(9).innerHTML="<select name='flag'><option value ='jboss'>jboss</option><option value ='etl'>etl</option><option value='cognos'>cognos</option><option value='hadoop'>hadoop</option></select>";
    newRow.insertCell(10).innerHTML= "<input size=9% type='button' value='删除' onclick=\"deleteRow()\"/>";
}

function deleteRow(){
   var rowIndex = event.srcElement.parentElement.parentElement.rowIndex;
   var styles = document.getElementById("table1");
   styles.deleteRow(rowIndex);
}

function sumbit_form(){
  var  myform = document.getElementById('submitForm');
myform.submit();
}
