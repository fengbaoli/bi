function ssh(obj) 
{    
   var objTr = obj.parentElement;
   var rowNum = objTr.rowIndex;
   var table = document.getElementById('table1');
   var filepath = 'D://343715//net//Xshell.exe'
   var username = table.rows[rowNum].cells[4].innerHTML; 
   var password = table.rows[rowNum].cells[5].name; 
   var hostname = table.rows[rowNum].cells[2].innerHTML; 
   var port =  table.rows[rowNum].cells[3].innerHTML; 
   var ssh =filepath+' -url '+'ssh://'+username+':'+password+'@'+hostname+':'+port;
   try    
   {    
    var objShell = new ActiveXObject("wscript.shell");    
    objShell.Run(ssh);    
    objShell = null; 	
   }    
   catch(e) 
   { 
        alert('找不到文件"'+"Xshell.exe"+'"(或它的组件之一)。请确定路径和文件名是否正确.')    
   }    
}
