function edit(element){
var e=event.srcElement; 

if(e.tagName=="TD")
{ 
	var r=e.parentElement.rowIndex +1; //当前点击行号 
	var c = e.cellIndex +1; //当前点击列号
}
　var oldhtml = element.innerHTML;//获得元素之前的内容
  //如果为flag列，编辑的时候需要下拉选择
  if (c == 10){
	  var newobj = document.createElement('select');//创建一个input元素
	  var d = [{t:'jboss',v:'jboss'},{t:'cognos',v:'cognos'},{t:'etl',v:'etl'},{t:'hadoop',v:'hadoop'}] ;
	  for(var i in d){
         var option = new Option(d[i].t,d[i].v);
         newobj.options.add(option);
    }
  }	else {
	  var newobj = document.createElement('input');//创建一个input元素
	  newobj.type = 'text';//为newobj元素添加类型
  }

  newobj.value=oldhtml;
　element.innerHTML = '';　　 //设置元素内容为空
　element.appendChild(newobj);//添加子元素
　newobj.focus();//获得焦点
  //设置newobj失去焦点的事件
newobj.onblur = function(){
//创建form表单
	var value1=this.value;
	var turnForm = document.createElement("form");    
	document.body.appendChild(turnForm);
	turnForm.method = 'post';
	turnForm.action = '/edit_resource/';
	var rowIndex = parseInt(r)-1;
	var idrowIndex=parseInt(r)-2;
	var cellIndex = parseInt(c)-1;  
	var tab=document.getElementById('table1');
	var obj = document.getElementsByName("myid");
	var  id = obj[idrowIndex].value
	switch(cellIndex)
	{
		case 0:
		  modify_contents = "update bi_resourceinfo set system_name ="+"'"+this.value+"'"+" where id="+"'"+id+"'";
		  break;
		case 1:
		  modify_contents = "update bi_resourceinfo set deploy_contents ="+"'"+this.value+"'"+" where id="+"'"+id+"'";
		  break;
		case 2:
		  modify_contents = "update bi_resourceinfo set ip_address ="+"'"+this.value+"'"+" where id="+"'"+id+"'";
		  break;
		case 3:
		  modify_contents = "update bi_resourceinfo set ssh_port ="+"'"+this.value+"'"+" where id="+"'"+id+"'";
		  break;
		case 4:
		  modify_contents = "update bi_resourceinfo set op_account ="+"'"+this.value+"'"+" where id="+"'"+id+"'";
		  break;
		case 5:
		  modify_contents = "update bi_resourceinfo set op_password ="+"'"+this.value+"'"+" where id="+"'"+id+"'";
		  break;
		case 6:
		  modify_contents = "update bi_resourceinfo set manager_account ="+"'"+this.value+"'"+" where id="+"'"+id+"'";
		  break;  
		case 7:
		  modify_contents = "update bi_resourceinfo set manager_password ="+"'"+this.value+"'"+" where id="+"'"+id+"'";
		  break; 
		case 8:
		  modify_contents = "update bi_resourceinfo set remarks ="+"'"+this.value+"'"+" where id="+"'"+id+"'";
		  break;
		case 9:
		  modify_contents = "update bi_resourceinfo set Flag ="+"'"+this.value+"'"+" where id="+"'"+id+"'";
		  break;
	}

	   //创建隐藏表单，提交sql
		var newElement = document.createElement("input");
		newElement.setAttribute("name","id");
		newElement.setAttribute("type","hidden");
		newElement.setAttribute("value",modify_contents);
		turnForm.appendChild(newElement);
		element.innerHTML = this.value ? this.value : oldhtml;
		if (element.innerHTML != oldhtml){   //如果修改了数据提交
		turnForm.submit();
		}
   }
}
