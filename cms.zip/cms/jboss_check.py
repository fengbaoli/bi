# -*- coding: utf-8 -*-
__author__ = '343715'
import urllib2
def JbossCheck(url):
    """

    :rtype : object
    """
    req = urllib2.Request(url)
    try:
        urllib2.urlopen(req,timeout=5)
        message = "ok"
    except urllib2.HTTPError, e:
        message = e.code
    except urllib2.URLError,e:
        message = e.reason
    return message
