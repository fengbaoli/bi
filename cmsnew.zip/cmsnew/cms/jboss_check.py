# -*- coding: utf-8 -*-
__author__ = '343715'
import urllib2
def JbossCheck(url):
    """

    :rtype : object
    """
    #user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    #request_headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0' }
    #headers = { 'User-Agent' : user_agent a
    req = urllib2.Request(url)
    try:
        urllib2.urlopen(req,timeout=5)
        message = "ok"
    except urllib2.HTTPError, e:
        message = e.code
    except urllib2.URLError,e:
        message = e.reason
    return message

