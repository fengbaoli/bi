from __future__ import division
# -*- coding: utf-8 -*-
import os,sys
sys.path.append('/home/appman/pythonlib')
import MySQLdb
import paramiko
import datetime

#project_list=['dpsor','dpods','dpstc','dpdpa','dpsrc','dpdsa','DPDOR','DPODS','DPSTC','DPDPA','DPSRC','DPDSA']
#project_list=[]  
path='/home/appman/cms/static/svncheckout/BI20161215-线上测试-20161202'    


#project_sql = "select deploy_contents  from bi_resourceinfo where flag='etl'"
#conn=MySQLdb.connect(host="localhost",user="bi",passwd="bi",db="bi_manager",charset="utf8")
#cursor = conn.cursor()
#cursor.execute(project_sql)
#result  = cursor.fetchall()
#for project_name in result:
#    upper_project_name =project_name[0].encode().upper()
#    project_list.append(project_name[0].encode())
#    project_list.append(upper_project_name)
#cursor.close()
#conn.close()

def get_project_name(path):
    project_list=[]
    project_sql = "select deploy_contents  from bi_resourceinfo where flag='etl'"
    conn=MySQLdb.connect(host="localhost",user="bi",passwd="bi",db="bi_manager",charset="utf8")
    cursor = conn.cursor()
    cursor.execute(project_sql)
    result  = cursor.fetchall()
    for project_name in result:
       upper_project_name =project_name[0].encode().upper()
       project_list.append(project_name[0].encode())
       project_list.append(upper_project_name)
    cursor.close()
    conn.close()
    return project_list



def get_project_filename(path):
    mylist = []
    project_list = get_project_name(path)
    for root, dirs, files in os.walk(path):
       for filename in files:
           project_name =  root.split("/")[-1]
           if project_name in project_list:
              mylist.append(root)
    mylist = list(set(mylist))
    return mylist

def counts_project_filename(path):
    mylist = []
    project_list = get_project_name(path)
    for root, dirs, files in os.walk(path):
       for filename in files:
           project_name =  root.split("/")[-1]
           if project_name in project_list:
              mylist.append(project_name+":"+filename)
    list1 = []
    #生成svn上的工程名列表
    olny_project_list=[]
    for contents in mylist:
        olny_project = contents.split(":")[0]
	olny_project_list.append(olny_project)
    olny_project_list = list(set(olny_project_list))
    for olny_project in olny_project_list:
     temp_list=()
     i = 0
     filename_list = ''
     temp_list=[] 
     for contents in mylist:
        ex_project_name = contents.split(":")[0]
	filename = contents.split(":")[1]
        if olny_project == ex_project_name:
           i = i+1
           if filename_list == '':
              filename_list = filename
           else:
	      filename_list=filename_list+"       "+filename
     temp_list=(olny_project,i,filename_list)
     list1.append(temp_list)
    return list1
def excute_sql(sql):
    conn=MySQLdb.connect(host="localhost",user="bi",passwd="bi",db="bi_manager",charset="utf8")
    cursor = conn.cursor()
    try: 
       cursor.execute(sql)
       conn.commit()
    except:
       conn.rollback()
    result  = cursor.fetchall()
    return result

def upload(hostname,username,password,port,local_dir,remote_dir):
    cmd = "rm -rf %s.svn" %(local_dir)
    os.system(cmd) 
    try:
        t=paramiko.Transport((hostname,port))
        t.connect(username=username,password=password)
        sftp=paramiko.SFTPClient.from_transport(t)
        for root,dirs,files in os.walk(local_dir):
            for filespath in files:
                local_file = os.path.join(root,filespath)
                a = local_file.replace(local_dir,'')
                remote_file = os.path.join(remote_dir,a)
                try:
                    sftp.put(local_file,remote_file)
                except Exception,e:
                    sftp.mkdir(os.path.split(remote_file)[0])
                    sftp.put(local_file,remote_file)
            for name in dirs:
                local_path = os.path.join(root,name)
                a = local_path.replace(local_dir,'')
                remote_path = os.path.join(remote_dir,a)
                try:
                    sftp.mkdir(remote_path)
                except Exception,e:
                    #print e
                    pass
        message = "ok"
        t.close()
    except Exception,e:
        message = "fail"
    return message
def ssh_connect (host,port,user,password):
 ssh=paramiko.SSHClient()
 ssh.load_system_host_keys()
 ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
 ssh.connect(host,port,user,password,timeout=30)
 return ssh


def ssh_cmd(hostname,username,password,port,cmd):
    s=ssh_connect(hostname,port,username,password)
    stdin,stdout,stderr = s.exec_command(cmd)
    cmd_result=stdout.read(),stderr.read()
    s.close()
def etl_deploy_job(path):
    mylist =get_project_filename(path)
    total_project_num=len(mylist) 
    start_project_num = 1
    #sftp文件
    message_list=[]
    for uploadpath in mylist:
        project_name = uploadpath.split("/")[-1].lower()
        speed_process =  round(start_project_num/total_project_num,1)*0.2*100
        sql = "select ip_address,ssh_port,op_account,op_password,Home from bi_resourceinfo where flag = 'etl' and deploy_contents=\'%s\'" %(project_name)
        result = excute_sql(sql)
        hostname = result[0][0]
        username = result[0][2]
        password = result[0][3]
        port = int(result[0][1])
        script_path = result[0][4]
        if script_path:
           remote_dir = script_path+"/ds_job/"+project_name
           cmd = "rm -rf %s" %(remote_dir+"/*")
           ssh_cmd(hostname,username,password,port,cmd)
           local_dir = uploadpath+"/"
           status =upload(hostname,username,password,port,local_dir,remote_dir)
           deploy_date=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
           message =deploy_date+ "  工程:"+project_name+" job文件复制完毕"
           speed_process =  round(start_project_num/total_project_num,1)*0.2*100
           sql = "insert into bi_progressstatus(speed_progress,message,status) values('%s','%s','%s')" %(speed_process,message,status)
           excute_sql(sql)
           start_project_num = start_project_num +1
        
    #return message_list 


#etl_deploy_job(path)
