from __future__ import division
import sys
sys.path.append('/home/appman/pythonlib')
import MySQLdb
import datetime
import urllib2
from bi_encrypt_decryp import encrypt,decrypt
import ConfigParser
cf = ConfigParser.ConfigParser()
key = 15
def readconfig(section):
    cf.read("/home/appman/cms/mylib/conf/database.conf")
    my_values =  cf.get("database",section)
    return my_values


def excute_sql(sql):
    conn=MySQLdb.connect(host=readconfig("db_hosts"),user=readconfig("db_user"),passwd=decrypt(key,readconfig("db_password")),db=readconfig("database"),charset="utf8")
    cursor = conn.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    cursor.close()
    conn.close()
    return result

def CognosCheck(url):
    """

    :rtype : object
    """
    #user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    #request_headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0' }
    #headers = { 'User-Agent' : user_agent }
    req = urllib2.Request(url)
    try:
        urllib2.urlopen(req,timeout=5)
        message = "ok"
    except urllib2.HTTPError, e:
        message = e.code
    except urllib2.URLError,e:
        message = e.reason
    return message
#bi_monitorjboss
sql = "select concat(\"http://\",ip_address,\":\",HttpPort,\"/\",ContextRoot) as url,ip_address,HttpPort from bi_resourceinfo where Flag='cognos'"
result  = excute_sql(sql)
mydate=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
for instances in result:
     url = instances[0]
     ip_address = instances[1] 
     HttpPort = instances[2]
     check_status=CognosCheck(url)
     insert_sql = "insert into bi_monitorcognos(monitor_date,ip,port,url,status) values('%s','%s','%s','%s','%s') " %(mydate,ip_address,HttpPort,url,check_status) 
     excute_sql(insert_sql)
