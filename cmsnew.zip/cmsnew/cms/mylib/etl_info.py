# -*- coding: utf-8 -*-
import paramiko,datetime,os
import sys,os
sys.path.append('/home/appman/pythonlib')
sys.path.append('/home/appman/cms/mylib')
import MySQLdb
import datetime
from bi_encrypt_decryp import encrypt,decrypt
import ConfigParser
cf = ConfigParser.ConfigParser()
key = 15
from sftp_get import *

def readconfig(section):
    cf.read("/home/appman/cms/mylib/conf/database.conf")
    my_values =  cf.get("database",section)
    return my_values
import MySQLdb
def excute_sql(sql):
    conn=MySQLdb.connect(host=readconfig("db_hosts"),user=readconfig("db_user"),passwd=decrypt(key,readconfig("db_password")),db=readconfig("database"),charset="utf8")
    cursor = conn.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    cursor.close()
    conn.close()
    return result
def ssh_connect (host,port,user,password):
 ssh=paramiko.SSHClient()
 ssh.load_system_host_keys()
 ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
 ssh.connect(host,port,user,password,timeout=30)
 return ssh

def ssh_cmd(hostname,username,password,port,cmd):
    s=ssh_connect(hostname,port,username,password)
    stdin,stdout,stderr = s.exec_command(cmd)
    cmd_result=stdout.read(),stderr.read()
    s.close()
    return cmd_result 

def export_job(cmd):
    ssh_cmd(hostname,username,password,int(port),cmd)


def ftpgetdir(sql,username,password,port,hostname):
    pro_list=excute_sql(sql)
    for pro in pro_list:
      project_name = pro[0]
      remote_path = '/tmp/etlinfo/'+str(project_name)
      local_path = '/tmp/etlinfo/'+str(project_name)
      if not os.path.exists(local_path):
         os.makedirs(local_path)
      host = Linux(hostname, int(port),username,password)
      host.sftp_get_dir(remote_path, local_path)

def generate_data():
    #获取数据源配置
    #sql = "select tns_name,tns_host,tns_port,tns_service_name  from bi_mysqldatasource union select tns_name,tns_host,tns_port,tns_service_name  from bi_oracledatasource where host_ip in (select ip_address  from bi_resourceinfo where flag = 'etl' group by ip_address) union  select tns_name,tns_host,tns_port,tns_service_name  from bi_gpdatasource where host_ip in (select ip_address  from bi_resourceinfo where flag = 'etl' group by ip_address)"
    #databasesource = excute_sql(sql) 
    #遍历当前目录
    items = os.listdir("/tmp/etlinfo")
    #定义env文件列表
    env_filename_list = []
    #筛选当前目录的env文件
    for names in items:
      if names.endswith(".env"):
        env_filename_list.append(names)
    #从env列表获取env文件名
    for env_filename in env_filename_list:
        env_filename = "/tmp/etlinfo/"+env_filename
        project_name =  env_filename.split(".")[0]
        my_pro = project_name.split("/")[-1]
        sql = "select tns_name,tns_host,tns_port,tns_service_name  from bi_datasource  where host_ip in (select ip_address  from bi_resourceinfo where flag = 'etl' and deploy_contents='%s')"  %(my_pro)
        databasesource = excute_sql(sql)
        tns_sql =  "select tns_name from bi_datasource  where host_ip in (select ip_address  from bi_resourceinfo where flag = 'etl' and deploy_contents='%s')"  %(my_pro)
        tns_list_temp = excute_sql(tns_sql)
        tns_list = [] 
        for tns in tns_list_temp:
             tns_list.append(tns[0])   
        path = project_name
        for root, dirs, files in os.walk(path):
            for filename in files:
                #打开env文件
                env_file = open(env_filename)
                while True:
                    #一行一行读取env文件内容
                    line = env_file.readline()
                    #获取env文件key值
                    env_key = line.split("=")[0]
                    if line:
                        #打开工程文件
                        pro_file = open(path+"/"+filename)
                        while True:
                            line2 = pro_file.readline()
                            pro_key = line2.replace("$","").strip("\n")
                            if line2:
                                #两个文件内容匹配
                                if  pro_key == env_key:
                                    #获取env文件的value值
                                    env_values = line.split("=")[1].strip("\n")
                                    if env_values in tns_list:
                                       for tns_name,tns_host,tns_port,tns_service_name in databasesource:
                                         if tns_name == env_values:
                                            insert_sql = "insert into bi_etljobinfo(projectname,jobname,parameterkey,parametervalue,datasourceip,datasourceport,datasourcedb) values('%s','%s','%s','%s','%s','%s','%s')" %(my_pro,filename,pro_key,env_values,tns_host,tns_port,tns_service_name)
                                            excute_sql(insert_sql)  
                                    #没有匹配写入数据库
                                    else:
                                       insert_sql="insert into bi_etljobinfo(projectname,jobname,parameterkey,parametervalue) values('%s','%s','%s','%s')" %(my_pro,filename,pro_key,env_values)
                                       excute_sql(insert_sql)
                            else:
                                break
                        pro_file.close()
                    else:
                        break
                env_file.close()
 
def move_env():
    import shutil
    import os 
    for root, dirs, files in os.walk("/tmp/etlinfo"):
      if dirs:
        for project_name in dirs:
            source_file="/tmp/etlinfo/"+project_name+"/"+project_name+".env"
            target_file="/tmp/etlinfo"
            shutil.move(source_file,target_file)      


if __name__=='__main__':
    #data back
    drop_sql ="drop table bi_etljobinfo_his"
    excute_sql(drop_sql)
    create_sql ="create table bi_etljobinfo_his as select *  from bi_etljobinfo"
    excute_sql(create_sql)
    truncate_sql = "truncate table bi_etljobinfo"
    excute_sql(truncate_sql)
    sshinfo_sql ="select op_account,op_password,ssh_port,ip_address  from bi_resourceinfo where flag ='etl' group by ip_address"
    for username,password,port,hostname in excute_sql(sshinfo_sql):
       #export 
       cmd = "source /opt/IBM/InformationServer/Server/DSEngine/dsenv;/usr/bin/python /home/dsadm/import/etl.py" 
       export_job(cmd)
       #sftp geta
       ftpsql ="select deploy_contents  from bi_resourceinfo where flag ='etl' and  ip_address='%s'" %(hostname)
       ftpgetdir(ftpsql,username,password,port,hostname)
       cmd ="rm -rf /tmp/etlinfo"
       ssh_cmd(hostname,username,password,int(port),cmd)
    move_env()
    #data generate
    generate_data()
    cmd = "rm -rf /tmp/etlinfo"
    os.system(cmd)  
