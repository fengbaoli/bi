import os,re
import commands
project_name=['dpods','dpstc','dpsor']


def get_jobinfo(project_name):
    cmd = "source /opt/IBM/InformationServer/Server/DSEngine/dsenv;dsjob  -ljobs %s" %(project_name)
    (status, output) = commands.getstatusoutput(cmd)
    job_list=output.split("\n")
    mypath = "/tmp/etlinfo/%s" %(project_name)
    if not os.path.exists(mypath):
       os.makedirs(mypath) 
    for jobname in  job_list:
       if jobname =='' or re.findall(r'Status',jobname):
          continue
       else:
          cmd = "source /opt/IBM/InformationServer/Server/DSEngine/dsenv;dsjob -lparams %s %s" %(project_name,jobname)
          (status, out) = commands.getstatusoutput(cmd)
          filename = mypath+"/"+jobname
          file = open(filename,"w+")  
          file.write(out) 
          file.close()     

def get_env(project_name):
    cmd = "source /opt/IBM/InformationServer/Server/DSEngine/dsenv;dsadmin  -listenv %s" %(project_name) 
    (status, out) = commands.getstatusoutput(cmd)
    filename = "/tmp/etlinfo/"+project_name+"/"+project_name+".env" 
    file = open(filename,"w+")
    file.write(out)
    file.close()

for pro in project_name:
    get_jobinfo(pro)
    get_env(pro)
