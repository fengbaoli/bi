from __future__ import division
import sys
sys.path.append('/home/appman/pythonlib')
import MySQLdb
import datetime
from bi_encrypt_decryp import encrypt,decrypt
import ConfigParser
cf = ConfigParser.ConfigParser()
key = 15
def readconfig(section):
    cf.read("/home/appman/cms/mylib/conf/database.conf")
    my_values =  cf.get("database",section)
    return my_values


def excute_sql(sql):
    conn=MySQLdb.connect(host=readconfig("db_hosts"),user=readconfig("db_user"),passwd=decrypt(key,readconfig("db_password")),db=readconfig("database"),charset="utf8")
    cursor = conn.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    cursor.close()
    conn.close()
    return result

def CdhCheck():
    cm_host__sql = "select parametervalues  from bi_sysparameter where sysparameter='cm_host'"
    cm_host=excute_sql(cm_host__sql)[0][0]
    cm_port_sql = "select parametervalues  from bi_sysparameter where sysparameter='cm_port'"
    cm_port = excute_sql(cm_port_sql)[0][0]
    cm_username_sql = "select parametervalues  from bi_sysparameter where sysparameter='cm_username'"
    cm_username  = excute_sql(cm_username_sql)[0][0]
    cm_password_sql = "select parametervalues  from bi_sysparameter where sysparameter='cm_password'"
    cm_password  = excute_sql(cm_password_sql)[0][0]
    from cm_api.api_client import ApiResource
    api = ApiResource(cm_host,cm_port,cm_username, cm_password)
    cdh5 = None
    serviceinfo=[]
    for c in api.get_all_clusters():
      if c.version == "CDH5":
         cdh5 = c
    for service in cdh5.get_all_services():
        temp_list=[]
        temp_list.append(service.name)
        temp_list.append(service.healthSummary)
        serviceinfo.append(temp_list)
    return serviceinfo

serviceinfo = CdhCheck()
ok_start = 0
mydate=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
for servicename,check_status in serviceinfo:
    insert_sql = "insert into bi_monitorcdh (monitor_date,servicename,servicestatus) values('%s','%s','%s')" %(mydate,servicename,check_status) 
    excute_sql(insert_sql)
