# -*- coding: utf-8 -*-
import datetime
import paramiko
import ConfigParser
import re,os
import sys
sys.path.append('/home/appman/pythonlib')
import MySQLdb
import datetime
import urllib2

def excute_sql(sql):
    conn=MySQLdb.connect(host="localhost",user="bi",passwd="bi",db="bi_manager",charset="utf8")
    cursor = conn.cursor()
    cursor.execute(sql)
    login_info  = cursor.fetchall()
    return login_info


def insertsql(sql):
    conn=MySQLdb.connect(host="localhost",user="bi",passwd="bi",db="bi_manager",charset="utf8")
    cursor = conn.cursor()
    try:
        cursor.execute(sql)
        message="ok"
    except:
        message="fail"
    return  message

def get_oracle_tns(host,port,user,password):
  ssh=paramiko.SSHClient()
  ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
  ssh.connect(host,port,user,password,timeout=30)
  get_oracle_home_cmd = 'source .bash_profile;source /etc/profile;source .bashrc;printenv'
  stdin,stdout,stderr = ssh.exec_command(get_oracle_home_cmd)
  for mypath in stdout.readlines():
     path_split = mypath.strip().split("=")
     if path_split[0] == "ORACLE_HOME":
        my_oracle_home = path_split[1]   
  ssh.close()
  tns_path = my_oracle_home+"/network/admin/tnsnames.ora"
  ssh=paramiko.SSHClient()
  ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
  ssh.connect(host,port,user,password,timeout=30)
  get_file_cmd="cat %s" %(tns_path)
  stdin,stdout,stderr = ssh.exec_command(get_file_cmd)
  tns_contents = stdout.readlines()
  return tns_contents   
 


def get_odbc(host,port,user,password):
  ssh=paramiko.SSHClient()
  ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
  ssh.connect(host,port,user,password,timeout=30)
  get_oracle_home_cmd = 'source .bash_profile;source /etc/profile;source .bashrc;printenv'
  stdin,stdout,stderr = ssh.exec_command(get_oracle_home_cmd)
  for mypath in stdout.readlines():
     path_split = mypath.strip().split("=")
     if path_split[0] == "ODBCINI":
        my_odbcini_home = path_split[1]
  ssh.close()
  ssh=paramiko.SSHClient()
  ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
  ssh.connect(host,port,user,password,timeout=30)
  get_file_cmd="cat %s|grep -v \"#\"|grep -E \"\[|=\"" %(my_odbcini_home)
  stdin,stdout,stderr = ssh.exec_command(get_file_cmd)
  odbc_contents = stdout.readlines()
  return odbc_contents 



def format_odbc(filename):
    host_ip = (filename.split("/")[-1]).split("-")[0]
    cf = ConfigParser.ConfigParser()
    cf.read(filename)
    mysql_driver="libmyodbc5w.so"
    gp_driver= "VMgplm00.so"
    postgresql_driver = "psqlodbcw.so"
    mysql_sections_list = []
    gp_sections_list = []
    for sections in cf.sections():
        for key_name in cf.items(sections):
            #mysql配置
            if re.findall(mysql_driver,key_name[1]):
                mysql_sections_list.append(sections)
            #GP配置
            if re.findall(gp_driver,key_name[1]):
                if re.findall("Greenplum Wire Protocol",sections):
                    pass
                else:
                    gp_sections_list.append(sections)
            if re.findall(postgresql_driver,key_name[1]):
                if re.findall("Greenplum Wire Protocol",sections):
                    pass
                else:
                    gp_sections_list.append(sections)

    mysql_list=[]
    gp_list = []
    #获取mysql的端口，用户，密码等配置
    for mysql_name  in mysql_sections_list:
        odbc_temp_list= []
        server_name = cf.get(mysql_name,"SERVER")
        port =cf.get(mysql_name,"PORT")
        database_name =cf.get(mysql_name,"DATABASE")
        odbc_temp_list.append(host_ip)
        odbc_temp_list.append(mysql_name)
        odbc_temp_list.append(server_name)
        odbc_temp_list.append(port)
        odbc_temp_list.append(database_name)
        odbc_temp_list.append("mysql")
        mysql_list.append(odbc_temp_list)
    #获取GP的端口，用户，密码等配置
    for gp_name  in gp_sections_list:
        odbc_temp_list= []
        options_list=cf.options(gp_name)
        if 'servername' in options_list:
            server_name = cf.get(gp_name,"Servername")
            port =cf.get(gp_name,"Port")
            database_name =cf.get(gp_name,"Database")
            odbc_temp_list.append(host_ip)
            odbc_temp_list.append(gp_name)
            odbc_temp_list.append(server_name)
            odbc_temp_list.append(port)
            odbc_temp_list.append(database_name)
            odbc_temp_list.append("gp")
            gp_list.append(odbc_temp_list)
        else :
           server_name = cf.get(gp_name,"HostName")
           port =cf.get(gp_name,"PortNumber")
           database_name =cf.get(gp_name,"Database")
           odbc_temp_list.append(host_ip)
           odbc_temp_list.append(gp_name)
           odbc_temp_list.append(server_name)
           odbc_temp_list.append(port)
           odbc_temp_list.append(database_name)
           odbc_temp_list.append("gp")
           gp_list.append(odbc_temp_list)
        options_list=[]
    return  mysql_list,gp_list


def format_oracle_tns(host,tns_contents):
    host_ip = host 
    #第一次格式化的初始列表（提取host，port，service，tnsname的列表）
    tns_list = []
    for line in tns_contents:
        #定义host匹配
        host = "HOST"
        #定义service_name匹配
        service_name = "SERVICE_NAME"
        #定义port匹配
        port = "PORT"
        if line:
           if re.match(r"^#",line):
              pass
           else:
 
              #获取tnsname
              if re.match(r"^\w+",line):
                 tnsname = line.replace('=','').strip()
                 tns_list.append(tnsname)
            #获取host
              if re.findall(host,line):
                 host = line.split("HOST")[1].split(")")[0].replace('=','').strip()
                 tns_list.append(host)
             #获取port
              if re.findall(port,line):
                 port= line.split(port)[1].replace(')','').replace('=','').strip()
                 tns_list.append(port)
            #获取service_name
              if re.findall(service_name,line):
                 s_name = line.replace('(','').replace(')','').split("=")[1]
                 tns_list.append(s_name)
        else:
            break
    #格式化列表
    #最终格式化的列表
    tnsname_list = []
    i = 0
    count = 1
    while  count <= len(tns_list)/4:
        #一元临时列表
        t_list = []
        t_name = tns_list[i]
        t_list.append(host_ip)
        t_list.append(t_name)
        t_host = tns_list[i+1]
        t_list.append(t_host)
        t_port = tns_list[i+2]
        t_list.append(t_port)
        t_service_name = tns_list[i+3].strip()
        t_list.append(t_service_name)
        #将一元列表加入到最终列表组成二元列表
        tnsname_list.append(t_list)
        i = i + 4
        count = count + 1
    return  tnsname_list


def datasource_insert_database():
    host_sql = "select ip_address,op_account,op_password,ssh_port  from bi_resourceinfo where flag  in('etl','cognos')  group by ip_address"
    myhost = excute_sql(host_sql)
    #onld data backup
    his_sql = "select  host_ip,tns_name,tns_host,tns_port,tns_service_name, flag   from bi_datasource"
    his_data = excute_sql(his_sql)
    for sigle_data in his_data:
        host_ip = sigle_data[0]
        tns_name = sigle_data[1]
        tns_host = sigle_data[2]
        tns_port = sigle_data[3]
        tns_service_name = sigle_data[4]
        flag  = sigle_data[5]
        his_insert_sql = "insert into bi_datasourcehistory (refresh_time,host_ip,tns_name,tns_host,tns_port,tns_service_name,flag) value('%s','%s','%s','%s','%s','%s','%s')" %(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),host_ip,tns_name,tns_host,tns_port,tns_service_name,flag)
        excute_sql(his_insert_sql)
    #truncate old data
    truncate_sql = "truncate table bi_datasource"
    excute_sql(truncate_sql)
    for hostinfo in myhost:
      host = hostinfo[0]
      user = hostinfo[1]
      password = hostinfo[2]
      port = int(hostinfo[3])
      tns_contents = get_oracle_tns(host,port,user,password)
      all_tns =  format_oracle_tns(host,tns_contents)
      message_list=[]
      for sigle_tns in all_tns:
          host_ip= sigle_tns[0]
          tns_name = sigle_tns[1]
          tns_host = sigle_tns[2]
          tns_port = sigle_tns[3]
          tns_service_name = sigle_tns[4]
          #write database
          insert_sql = "insert into bi_datasource(host_ip,tns_name,tns_host,tns_port,tns_service_name,flag) values('%s','%s','%s','%s','%s','oracle')" %(host_ip,tns_name,tns_host,tns_port,tns_service_name)
          message=insertsql(insert_sql)
          message_list.append(message)
      
    for hostinfo in myhost:
      host = hostinfo[0]
      user = hostinfo[1]
      password = hostinfo[2]
      port = int(hostinfo[3])
      odbc_contents = get_odbc(host,port,user,password)
      odbc_filename = host+"-odbc.ini"
      odbc_file_path="/tmp/"+odbc_filename
      if os.path.exists(odbc_file_path):
            os.remove(odbc_file_path)
      odbc_file = open(odbc_file_path,"a+")
      for odbc_contents in odbc_contents:
            odbc_file.write(odbc_contents)
      odbc_file.close()
      #文件解析 
      format_odbc_contents = format_odbc(odbc_file_path)
      mysql_odbc = format_odbc_contents[0]
      gp_odbc =  format_odbc_contents[1]
      if mysql_odbc:
         for mysql_contents in mysql_odbc:
          host_ip= mysql_contents[0]
          tns_name = mysql_contents[1]
          tns_host = mysql_contents[2]
          tns_port = mysql_contents[3]
          tns_service_name = mysql_contents[4]
          flag = mysql_contents[5]
          #write database
          insert_sql = "insert into bi_datasource (host_ip,tns_name,tns_host,tns_port,tns_service_name,flag) values('%s','%s','%s','%s','%s','%s')" %(host_ip,tns_name,tns_host,tns_port,tns_service_name,flag)
          message=insertsql(insert_sql)
          message_list.append(message)
      if gp_odbc:
         for  gp_contents in gp_odbc:
          host_ip= gp_contents[0]
          tns_name = gp_contents[1]
          tns_host = gp_contents[2]
          tns_port =gp_contents[3]
          tns_service_name = gp_contents[4]
          flag = gp_contents[5]
          #write database
          insert_sql = "insert into bi_datasource (host_ip,tns_name,tns_host,tns_port,tns_service_name,flag) values('%s','%s','%s','%s','%s','%s')" %(host_ip,tns_name,tns_host,tns_port,tns_service_name,flag)
          message = insertsql(insert_sql)
          message_list.append(message)
    return  message_list
