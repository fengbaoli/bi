# -*- coding: utf-8 -*-

from django.db import models
from django.forms import ModelForm
import django.forms as forms




class ResourceInfo(models.Model):
    system_name = models.CharField('系统名 cluster_name',max_length=50)
    deploy_contents = models.CharField('部署内容 Name',max_length=50)
    ip_address = models.CharField('IP地址 Host',max_length=50)
    ssh_port = models.CharField('ssh端口',max_length=50)
    op_account = models.CharField('运维账号 User',max_length=50)
    op_password = models.CharField('运维密码 Password',max_length=50)
    manager_account = models.CharField('manager账号 User',max_length=50,null=True)
    manager_password = models.CharField('manager密码 Password',max_length=50,null=True)
    remarks = models.CharField('备注',max_length=250,null=True)
    ssh_status = models.CharField('可登陆状态',max_length=50,default="N/A")
    AcceptCount = models.CharField('可接受连接数',max_length=50,null=True)
    JmxPort= models.CharField('JmxPort',max_length=50,null=True)
    AppDir= models.CharField('包上传路径',max_length=50,null=True)
    HttpPort= models.CharField('可登陆状态',max_length=50,null=True)
    Xmx = models.CharField('Xmx',max_length=50,null=True)
    File = models.CharField('包名',max_length=50,null=True)
    ContextRoot = models.CharField('验证地址',max_length=50,null=True)
    Xms = models.CharField('Xms',max_length=50,null=True)
    Home = models.CharField('jboss安装目录',max_length=50,null=True)
    LogFile = models.CharField('jboss日志路径',max_length=50,null=True)
    Flag = models.CharField('jboss或cognos或etl',max_length=50,null=True)


class MonitorJboss(models.Model):
    monitor_date=models.DateTimeField('检查日期')
    system_name = models.CharField('系统名 cluster_name',max_length=50)
    deploy_contents = models.CharField('部署内容 Name',max_length=50)
    url = models.CharField('登陆url',max_length=50,null=True)
    ip_address = models.CharField('IP地址 Host',max_length=50)
    HttpPort = models.CharField('登陆端口',max_length=50)
    check_status= models.CharField('可登陆状态',max_length=50)


class SysParameter(models.Model):
    sysparameter = models.CharField('参数名',max_length=50)
    parametervalues = models.CharField('值',max_length=50)



class ProgressStatus(models.Model):
    speed_progress = models.CharField('进度',max_length=50)
    message = models.CharField('部署日志',max_length=50)
    status = models.CharField('状态',max_length=50)

class MonitorCognos(models.Model):
    monitor_date=models.DateTimeField('检查日期')
    ip = models.CharField('ip',max_length=50)
    port = models.CharField('port',max_length=50)
    url = models.CharField('url',max_length=50)
    status = models.CharField('状态',max_length=50)



class MonitorCdh(models.Model):
    monitor_date=models.DateTimeField('检查日期')
    servicename = models.CharField('组件名',max_length=50)
    servicestatus = models.CharField('组件运行状态',max_length=50)



class Datasource(models.Model):
    host_ip = models.CharField('主机地址',max_length=50)
    tns_name = models.CharField('TNS名',max_length=50)
    tns_host = models.CharField('TNS host',max_length=50)
    tns_port = models.CharField('TNS 端口',max_length=50)
    tns_service_name = models.CharField('TNS servicename',max_length=50)
    flag = models.CharField('标记位',max_length=50) 

class DatasourceHistory(models.Model):
    refresh_time = models.DateTimeField('刷新日期')
    host_ip = models.CharField('主机地址',max_length=50)
    tns_name = models.CharField('连接名',max_length=50)
    tns_host = models.CharField('连接 host',max_length=50)
    tns_port = models.CharField('mysql 端口',max_length=50)
    tns_service_name = models.CharField('mysql database',max_length=50)
    flag = models.CharField('标记位',max_length=50)



class HealthyRate(models.Model):
     monitor_time = models.DateTimeField('监控日期') 
     system_name = models.CharField('系统名',max_length=50)
     healthy_rate = models.CharField('系统名',max_length=50)



class EtlJobInfo(models.Model):
     projectname  = models.CharField('工程名',max_length=50) 
     jobname   = models.CharField('job名',max_length=50)
     parameterkey  = models.CharField('参数',max_length=50)
     parametervalue  = models.CharField('值',max_length=50)
     datasourceip = models.CharField('数据源ip',max_length=50)
     datasourceport = models.CharField('数据源端口',max_length=50)
     datasourcedb = models.CharField('数据源database',max_length=50)


class EtlDeployMessage(models.Model):
     deploy_time = models.DateTimeField('部署日期')
     project_name = models.CharField('工程名',max_length=50)
     job_name  = models.CharField('job名',max_length=50)
     deploy_setp = models.CharField('部署步骤',max_length=50)
     deploy_status = models.IntegerField()
     failed_reason = models.CharField('失败原因',max_length=500,null=True)



class AlarmInfo(models.Model):
      monitor_time = models.DateTimeField('告警时间')
      system_name = models.CharField('系统名',max_length=50)
      servicename = models.CharField('服务名',max_length=50)
      alarm_level = models.CharField('告警级别',max_length=50)
      alarm_info = models.CharField('告警信息',max_length=50)
