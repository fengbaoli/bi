# -*- coding: utf-8 -*-
from django.views.decorators.cache import cache_page
import xlwt
from getdatasource import *
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required #django用户认证
from django.db.models import Q
from django.contrib import auth
import  json
from jboss_log import  JbossLog
from jboss_check import  JbossCheck
from etl_deploy import counts_project_filename
from etl_deploy import etl_deploy_job
from django.shortcuts import  render_to_response
from  django.http import HttpResponse
from django.http import  HttpResponseRedirect
from django.db import connection,transaction
from django.contrib.auth.decorators import login_required  
from cms.bi.models  import  ResourceInfo
from django.contrib.auth.models import User
import MySQLdb
import MySQLdb.cursors
import random,os
import sys,re
reload(sys)
sys.setdefaultencoding("utf-8")
@login_required
def logout(request):
    auth.logout(request)
    return HttpResponseRedirect("/login/")

@login_required
def resource(request):
    sql = "select system_name,deploy_contents,ip_address,ssh_port,op_account,op_password,manager_account,manager_password,remarks,ssh_status from bi_resourceinfo group by ip_address"
    cursor = connection.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    return  render_to_response('resource.html',{'resourceinfo':result})

from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from cms.bi.models import  ResourceInfo
#@cache_page(60 * 15)
@login_required
def edit_resource(request):
    mydata = request.POST.get('data','')
    myid = request.POST.get('myid', '');
    system_name = request.POST.get('system_name', '');
    new_system_name = request.POST.get('new_system_name', '');
    deploy_contents = request.POST.get('deploy_contents', '');
    ip_address = request.POST.get('ip_address', '');
    ssh_port = request.POST.get('ssh_port', '');
    op_account = request.POST.get('op_account', '');
    op_password = request.POST.get('op_password', '');
    manager_account = request.POST.get('manager_account', '');
    manager_password = request.POST.get('manager_password', '');
    remarks = request.POST.get('remarks', '')
    flag =request.POST.get('Flag', '')
    delid = request.POST.get('delid', '');
    export = request.POST.get('export')
    fresh = request.POST.get('refresh')
    ref = request.POST.get('ref')
    if new_system_name:
       resourceinfo=ResourceInfo(system_name=new_system_name,deploy_contents=deploy_contents,ip_address=ip_address,ssh_port=ssh_port,op_account=op_account,op_password=op_password,manager_account=manager_account,manager_password=manager_password,remarks=remarks,Flag=flag)
       resourceinfo.save()
       contact_list=ResourceInfo.objects.only('id','system_name','deploy_contents','ip_address','ssh_port','op_account','op_password','manager_account','manager_password','remarks','Flag')
       paginator = Paginator(contact_list, int(10))
       defaultpage = 1
       page = request.GET.get('page')
       if page:
         contacts = paginator.page(page)
       else:
         contacts = paginator.page(defaultpage)
       return render_to_response('edit_resource.html', {'contacts': contacts}) 
    if mydata:
       list_data = json.loads(mydata) 
       '''
       for sing_data in list_data: 
	      system_name=sing_data[u'系统名']
              deploy_contents = sing_data[u'部署内容']
              ip_address = sing_data[u'IP地址']
              ssh_port = sing_data[u'ssh端口']
              op_account = sing_data[u'运维账号']
              op_password = sing_data[u'运维密码']
              manager_account = sing_data[u'manager账号']
              manager_password = sing_data[u'manager密码']
	      remarks = sing_data[u'备注']
              Flag = sing_data[u'部署类型']
  
              print system_name
              print deploy_contents
              print ip_address
              print ssh_port
              print op_account
              print op_password
              print manager_account
              print manager_password
              print remarks
              print Flag 
       ''' 
       contact_list=ResourceInfo.objects.only('id','system_name','deploy_contents','ip_address','ssh_port','op_account','op_password','manager_account','manager_password','remarks','Flag')
       paginator = Paginator(contact_list, int(10))
       defaultpage = 1
       page = request.GET.get('page')
       if page:
         contacts = paginator.page(page)
       else:
         contacts = paginator.page(defaultpage)
       return render_to_response('edit_resource.html', {'contacts': contacts,'data':'ok'})
    if ref :
       contact_list=ResourceInfo.objects.only('id','system_name','deploy_contents','ip_address','ssh_port','op_account','op_password','manager_account','manager_password','remarks','Flag')
       paginator = Paginator(contact_list, int(10))
       defaultpage = 1
       page = request.GET.get('page')
       if page:
         contacts = paginator.page(page)
       else:
         contacts = paginator.page(defaultpage)
       return render_to_response('edit_resource.html', {'contacts': contacts})
    if export =='export':
       pattern = xlwt.Pattern() # Create the Pattern
       pattern.pattern = xlwt.Pattern.SOLID_PATTERN # May be: NO_PATTERN, SOLID_PATTERN, or 0x00 through 0x12
       borders = xlwt.Borders()
       borders.left = xlwt.Borders.DASHED
       borders.right = xlwt.Borders.DASHED
       borders.top = xlwt.Borders.DASHED
       borders.bottom = xlwt.Borders.DASHED
       borders.left_colour = 0x40
       borders.right_colour = 0x40
       borders.top_colour = 0x40
       borders.bottom_colour = 0x40
       style0 = xlwt.easyxf('font: name Times New Roman, color-index red, bold on',num_format_str='#,##0.00')
       response = HttpResponse(mimetype='application/vnd.ms-excel')
       response['Content-Disposition'] = 'attachment;filename=resourceinfo.xls'
       wb = xlwt.Workbook(encoding = 'utf-8')
       #第一列格式化
       sheet = wb.add_sheet(u'环境信息表')
       #1st line   
       sheet.write(0,0, '系统名',style0)
       sheet.write(0,1, '部署内容',style0)
       sheet.write(0,2, 'IP地址',style0)
       sheet.write(0,3, 'ssh端口',style0)
       sheet.write(0,4, '运维账号',style0)
       sheet.write(0,5, '运维密码',style0)
       sheet.write(0,6, 'manager账号',style0)
       sheet.write(0,7, 'manager密码',style0)
       sheet.write(0,8, '备注',style0)
       sheet.write(0,9, '部署类型',style0)
       row = 1
       for agencycustomer in ResourceInfo.objects.only('system_name','deploy_contents','ip_address','ssh_port','op_account','op_password','manager_account','manager_password','remarks','Flag'):
          sheet.write(row,0, agencycustomer.system_name)
          sheet.write(row,1, agencycustomer.deploy_contents)
          sheet.write(row,2, agencycustomer.ip_address)
          sheet.write(row,3, agencycustomer.ssh_port)
          sheet.write(row,4, agencycustomer.op_account)
          sheet.write(row,5, agencycustomer.op_password)
	  sheet.write(row,6, agencycustomer.manager_account)
	  sheet.write(row,7, agencycustomer.manager_password)
	  sheet.write(row,8, agencycustomer.remarks)
	  sheet.write(row,9, agencycustomer.Flag)
          row=row + 1
       import StringIO
       output = StringIO.StringIO()
       wb.save(output)
       output.seek(0)
       response.write(output.getvalue())
       return response 
    if system_name:
       up_sql = "update bi_resourceinfo set system_name='%s',deploy_contents='%s',ip_address='%s',ssh_port='%s',op_account='%s',op_password='%s',manager_account='%s',manager_password='%s',remarks='%s',flag='%s' where id=%s" %(system_name,deploy_contents,ip_address,ssh_port,op_account,op_password,manager_account,manager_password,remarks,flag,myid) 
       cursor = connection.cursor()
       cursor.execute(up_sql)
       contact_list=ResourceInfo.objects.only('id','system_name','deploy_contents','ip_address','ssh_port','op_account','op_password','manager_account','manager_password','remarks','Flag')
       paginator = Paginator(contact_list, int(10))
       defaultpage = 1
       page = request.GET.get('page')
       if page:
         contacts = paginator.page(page)
       else:
         contacts = paginator.page(defaultpage)
       return render_to_response('edit_resource.html', {'contacts': contacts})
    if delid:
       delsql = "delete from bi_resourceinfo where id=%s" %(delid)
       cursor = connection.cursor()
       cursor.execute(delsql)
       contact_list=ResourceInfo.objects.only('id','system_name','deploy_contents','ip_address','ssh_port','op_account','op_password','manager_account','manager_password','remarks','Flag')
       paginator = Paginator(contact_list, int(10))
       defaultpage = 1
       page = request.GET.get('page')
       if page:
         contacts = paginator.page(page)
       else:
         contacts = paginator.page(defaultpage)
       return render_to_response('edit_resource.html', {'contacts': contacts})
    else:
       contact_list=ResourceInfo.objects.only('id','system_name','deploy_contents','ip_address','ssh_port','op_account','op_password','manager_account','manager_password','remarks','Flag')
       paginator = Paginator(contact_list, int(10))
       defaultpage = 1
       page = request.GET.get('page')
       if page:
         contacts = paginator.page(page)
       else:
         contacts = paginator.page(defaultpage)
       return render_to_response('edit_resource.html', {'contacts': contacts})

def resource_import(request):
    mydata = request.POST.get('data','')
    if mydata:
       list_data = json.loads(mydata) 
       message =['excel导入成功!']
    return HttpResponse(json.dumps({"message":message})) 
def edit_resource_search(request):
    if request.POST:
       search = request.POST.get('search')
    else:
       search = request.GET.get('search')
    resourceinfo=ResourceInfo.objects.only('id','system_name','deploy_contents','ip_address','ssh_port','op_account','op_password','manager_account','manager_password','remarks','Flag').filter(Q(system_name__icontains=search)|Q(deploy_contents__icontains=search)|Q(ip_address__icontains=search)|Q(ssh_port__icontains=search)|Q(op_account__icontains=search)|Q(op_password__icontains=search)|Q(manager_account__icontains=search)|Q(manager_password__icontains=search)|Q(remarks__icontains=search)|Q(Flag__icontains=search)) 
    paginator = Paginator(resourceinfo, int(10))
    defaultpage = 1
    page = request.GET.get('page')
    if page:
       resourceinfos = paginator.page(page)
    else:
       resourceinfos = paginator.page(defaultpage)
    return render_to_response('edit_resource.html', {'resourceinfos':resourceinfos,'search':search})
@login_required
def resource_info(request):
    return  render_to_response('resource_info.html',{'ip_address':ip_address})
@login_required
def jboss_deploy(request):
    svn_address = request.POST.get('svn_address', '').strip("/")
    if svn_address:
        filename_path = svn_address.split("/")[-1]
        current_checkout_path=os.getcwd()+"/static/svncheckout/"+filename_path
        if not os.path.exists(current_checkout_path):
            svnlogpath=os.getcwd()+"/static/svncheckout/"+"svn_checkout.log"
            svn_cmd='/usr/bin/svn co --username %s --password %s   %s   %s >%s 2>&1'  % ('343715','343715',svn_address,current_checkout_path,svnlogpath)
            result=os.system(svn_cmd)
            if result == 0:
                
                return render_to_response('jboss_deploy_two.html')
            else:
                file = open(svnlogpath)
                contents =file.read()
                contents=''.join([one for one in contents.split('\n')])
                print type(contents)
                file.close()
                return render_to_response('jboss_deploy_one_error.html',{'contents':contents})
        else:
            svnlogpath=os.getcwd()+"/static/svncheckout/"+"svn_checkout.log"
            svn_cmd='/usr/bin/svn up --username %s --password %s   %s   %s >%s 2>&1'  % ('343715','343715',svn_address,current_checkout_path,svnlogpath)
            result=os.system(svn_cmd)
            if result == 0:
                
                return render_to_response('jboss_deploy_two.html')
            else:
                file = open(svnlogpath)
                contents =file.read()
                contents=''.join([one for one in contents.split('\n')])
                print type(contents)
                file.close()
                return render_to_response('jboss_deploy_one_error.html',{'contents':contents})
    return render_to_response('jboss_deploy.html')
@login_required
def manager_index(request):
    time_sql = "select parametervalues from bi_sysparameter where sysparameter='query_interval_time'"
    cursor = connection.cursor()
    cursor.execute(time_sql)
    result  = cursor.fetchall()
    datelist = []
    for mytime in result:
       date_sql ="select monitor_time from bi_healthyrate where system_name='cognos'and  monitor_time >=date_sub(now(), interval %s minute) " %(str(mytime[0]))
    cursor = connection.cursor()
    cursor.execute(date_sql)
    mydatetuple  = cursor.fetchall() 
    for mydate in mydatetuple:
        datelist.append(mydate[0].strftime('%H:%M:%S'))
    for mytime in result:
       sql ="select system_name,healthy_rate  from bi_healthyrate where monitor_time >=date_sub(now(), interval %s minute)" %(str(mytime[0]))
    cursor = connection.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    mdmpdata = []
    bidata = []
    nbidata = []
    cdhdata = []
    mbidata = []
    evsdata = []
    cognosdata = []
    for mydata in result:
        if mydata[0] == 'cognos':
           cognosdata.append(mydata[1])
        if mydata[0] == 'BI':
           bidata.append(mydata[1])
        if mydata[0] == 'CDH':
           cdhdata.append(mydata[1])
        if mydata[0] == 'EVS':
           evsdata.append(mydata[1])
        if mydata[0] == 'MBI':
           mbidata.append(mydata[1])
        if mydata[0] == 'MDMP':
           mdmpdata.append(mydata[1])
        if mydata[0] == 'NBI':
           nbidata.append(mydata[1]) 

    #获取告警信息
    alarm_sql="select monitor_time,system_name,servicename,alarm_level,alarm_info  from bi_alarminfo  order by monitor_time desc limit 6"
    cursor = connection.cursor()
    cursor.execute(alarm_sql)
    alarminfo = cursor.fetchall()
    #计算资源分布
    jboss_sql = "select (select count(*) from bi_resourceinfo where flag='jboss')/(select count(*)  from bi_resourceinfo)*100"
    cursor.execute(jboss_sql)
    jboss_num =  cursor.fetchall()[0][0]
    hadoop_sql = "select (select count(*) from bi_resourceinfo where flag='hadoop')/(select count(*)  from bi_resourceinfo)*100"
    cursor.execute(hadoop_sql)
    hadoop_num =  cursor.fetchall()[0][0]
    etl_sql = "select (select count(*) from bi_resourceinfo where flag='etl')/(select count(*)  from bi_resourceinfo)*100"
    cursor.execute(etl_sql)
    etl_num =  cursor.fetchall()[0][0]
    cognos_sql = "select (select count(*) from bi_resourceinfo where flag='cognos')/(select count(*)  from bi_resourceinfo)*100"
    cursor.execute(cognos_sql)
    cognos_num =  cursor.fetchall()[0][0]
    return render_to_response('manager_index.html',{'mydate':datelist,'cognos':cognosdata,'bi':bidata,'cdh':cdhdata,'evs':evsdata,'mbi':mbidata,'mdmp':mdmpdata,'nbi':nbidata,'alarminfo':alarminfo,'jboss_num':jboss_num,'hadoop_num':hadoop_num,'etl_num':etl_num,'cognos_num':cognos_num})
@login_required
def xml_import_export(request):
    # 获取文件
    Flag = "jboss"
    file_obj = request.FILES.get('your_file', None)
    save_path=os.getcwd()+"/static/upload/"
    if file_obj:
    # 写入文件
       file_name = 'temp_file-%d' % random.randint(0,100000) # 不能使用文件名称，因为存在中文，会引起内部错误
       file_full_path = os.path.join(save_path, file_name)
       dest = open(file_full_path,'wb+')
       dest.write(file_obj.read())
       dest.close()
       #解析xml
       from formatxml import formatXml
       xmlcontents = formatXml().formatxml(file_full_path)
       for resourceinfo in  xmlcontents:
           logfilepath =resourceinfo['Home']+"/"+resourceinfo['Name']+"/log"
           p =  ResourceInfo(system_name=resourceinfo['cluster_name'],deploy_contents=resourceinfo['Name'],ip_address=resourceinfo['Host'],ssh_port=resourceinfo['Port'],op_account=resourceinfo['User'],op_password=resourceinfo['Password'],AcceptCount=resourceinfo['AcceptCount'],JmxPort=resourceinfo['JmxPort'],AppDir=resourceinfo['AppDir'],HttpPort=resourceinfo['HttpPort'],Xmx=resourceinfo['Xmx'],File=resourceinfo['File'],ContextRoot=resourceinfo['ContextRoot'],Xms=resourceinfo['Xms'],Home=resourceinfo['Home'],LogFile=logfilepath,Flag=Flag)
           p.save()
       return render_to_response('xml_import_export.html',{})
    return render_to_response('xml_import_export.html',{})


#各种日志拉取
@login_required
def jboss_log(request):
    ipaddress =  request.POST.get('ipaddress', '')
    if ipaddress:
      sql = "select op_account,op_password,ssh_port,GROUP_CONCAT(LogFile) from bi_resourceinfo where Flag = 'jboss' and    ip_address=\'%s\'" %(ipaddress)
      cursor = connection.cursor()
      cursor.execute(sql)
      result  = cursor.fetchall()
      for username,password,ssh_port,logspath in result:
        log_info = JbossLog().GetLogInfo(str(ipaddress),username,password,int(ssh_port),str(logspath))
      return  render_to_response('jboss_log.html',{'log_info':log_info})
    else:
      return  render_to_response('jboss_log.html')
@login_required
def filedownload(request):
    file_name = request.POST.get('filename',None)
    filename = file_name.split("/")[-1]
    ssh_str = request.POST.get('ssh_str',None)
    ip = ssh_str.split("|||")[0]
    username = ssh_str.split("|||")[1]
    password = ssh_str.split("|||")[2]
    ssh_port = ssh_str.split("|||")[3]
    #remote download file
    import shutil
    if os.path.exists(os.getcwd()+"/static/download/"):
       shutil.rmtree(os.getcwd()+"/static/download/")
       os.mkdir(os.getcwd()+"/static/download/")
    else:
       os.mkdir(os.getcwd()+"/static/download/")
    import paramiko
    t = paramiko.Transport((ip,int(ssh_port)))
    t.connect(username=username, password=password)  # 登录远程服务器
    sftp = paramiko.SFTPClient.from_transport(t)   # sftp传输协议
    src =file_name
    des =os.getcwd()+"/static/download/"+filename
    sftp.get(src,des)
    t.close()
    def readFile(des, buf_size=262144):
        #打开日志文件
        f = open(des, "rb")
        #按照缓存大小进行文件加载
        while True:
            log_contents = f.read(buf_size)
            #对文件中的敏感数据进行替换
            replace_log_contents= log_contents.replace("laosiji1@etl","password")
            if replace_log_contents:
                yield replace_log_contents
            else:
                break
        f.close()
    response = HttpResponse(readFile(des), content_type='APPLICATION/OCTET-STREAM')
    response['Content-Disposition'] = 'attachment; filename='+filename.encode('utf-8')
    response['Content-Length'] = os.path.getsize(des)
    return response
@login_required
def jboss_log_search(request):
    sql = "select ip_address,GROUP_CONCAT(File SEPARATOR '|') from bi_resourceinfo where Flag = 'jboss' group by ip_address"
    cursor = connection.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    return  render_to_response('jboss_log_search.html',{'ipaddress':result})


#监控
@login_required
def jboss_monitor(request):
      sql = "select system_name,deploy_contents,concat(\"http://\",ip_address,\":\",HttpPort,\"/\",ContextRoot) as url,ip_address,HttpPort from bi_resourceinfo where Flag='jboss'" 
      cursor = connection.cursor()
      cursor.execute(sql)
      result  = cursor.fetchall()
      message_list =[]
      for instances in result:
          systemname = instances[0]
          deploy_contents = instances[1]
          url = instances[2]
          ip_address = instances [3]
          HttpPort = instances[4]
          check_status=JbossCheck(url)
          tup=(systemname,deploy_contents,ip_address,HttpPort,check_status)
          message_list.append(tup)
      return  render_to_response('jboss_monitor.html',{'status':message_list})
@login_required
def jboss_system_search(request):
    sql = "select system_name,GROUP_CONCAT(deploy_contents SEPARATOR '|') as deploy_contents from bi_resourceinfo where Flag='jboss' group by system_name"
    cursor = connection.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    return  render_to_response('jboss_system_search.html',{'system_name':result})
@login_required
def systemparamter(request):
    parameter_sql = "select sysparameter  from bi_sysparameter"
    cursor = connection.cursor()
    cursor.execute(parameter_sql)
    result  = cursor.fetchall()
    temp_dic = {}
    for sysparameter in result:
        temp_sysparameter=request.POST.get(sysparameter[0], '')
        if temp_sysparameter:
            temp_dic[sysparameter] = temp_sysparameter
    #字典不为空进行数据更新
    if temp_dic:
        for paramter in temp_dic:
            #print paramter[0]
            sql  = "update bi_sysparameter set parametervalues=\'%s\' where sysparameter = \'%s\' " %(str(temp_dic[paramter]),str(paramter[0]))
            cursor.execute(sql)
    sql = "select sysparameter,parametervalues  from bi_sysparameter"
    cursor = connection.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    return render_to_response('systemparamter.html',{'systemparameter':result})




#etl环境编辑管理
@login_required
def etl_manager(request):
    edit_sql = request.POST.get('id', '');
    if edit_sql:
        cursor = connection.cursor()
        cursor.execute(edit_sql)
        sql = "select id,system_name,deploy_contents,ip_address,Home  from bi_resourceinfo where Flag=\'%s\'" % ("etl")
        cursor = connection.cursor()
        cursor.execute(sql)
        result  = cursor.fetchall()
        return  render_to_response("etl_manager.html",{'etl_resource':result})
    else:
        sql = "select id,system_name,deploy_contents,ip_address,Home  from bi_resourceinfo where Flag=\'%s\'" % ("etl")
        cursor = connection.cursor()
        cursor.execute(sql)
        result  = cursor.fetchall()
        return  render_to_response("etl_manager.html",{'etl_resource':result})
@login_required
def etl_deploy(request):
    svn_address = request.POST.get('svn_address', '').strip("/")
    deploy_filename = request.POST.get('deploy_filename', '').strip("/")
    if svn_address:
        filename_path = svn_address.split("/")[-1]
        current_checkout_path=os.getcwd()+"/static/svncheckout/"+filename_path
        if not os.path.exists(current_checkout_path):
            svnlogpath=os.getcwd()+"/static/svncheckout/"+"svn_checkout.log"
            svn_cmd='/usr/bin/svn co --username %s --password %s   %s   %s >%s 2>&1'  % ('343715','343715',svn_address,current_checkout_path,svnlogpath)
            result=os.system(svn_cmd)
            if result == 0:
                svn_contents = counts_project_filename(current_checkout_path)  
                return render_to_response('etl_deploy_two.html',{'svn_contents':svn_contents,'filename_path':filename_path})
            else:
                file = open(svnlogpath)
                contents =file.read()
                contents=''.join([one for one in contents.split('\n')])
                print type(contents)
                file.close()
                return render_to_response('etl_deploy_one_error.html',{'contents':contents})
        else:
            svnlogpath=os.getcwd()+"/static/svncheckout/"+"svn_checkout.log"
            svn_cmd='/usr/bin/svn up --username %s --password %s   %s   %s >%s 2>&1'  % ('343715','343715',svn_address,current_checkout_path,svnlogpath)
            result=os.system(svn_cmd)
            if result == 0:
                svn_contents =counts_project_filename(current_checkout_path)
                return render_to_response('etl_deploy_two.html',{'svn_contents':svn_contents,'filename_path':filename_path})
            else:
                file = open(svnlogpath)
                contents =file.read()
                contents=''.join([one for one in contents.split('\n')])
                print type(contents)
                file.close()
                return render_to_response('etl_deploy_one_error.html',{'contents':contents})
    if deploy_filename:
        path = str(os.getcwd()+"/static/svncheckout/"+deploy_filename)
        etl_deploy_job(path)
        return render_to_response('etl_deploy_three.html')    
    return render_to_response('etl_deploy.html')
@login_required
def get_progress_info(request):
    sql = "select speed_progress,message,status  from bi_progressstatus"
    cursor = connection.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    speed_progress_list=[]
    message_list = []
    status_list = []
    for contents in result:
       speed_progress_list.append(float(contents[0].encode("utf-8")))
       message_list.append(contents[1])
       status_list.append(contents[2])
    if 'fail' in status_list:
       status = 'fail'
       message = json.dumps(message_list)
       speed_progress=max(speed_progress_list) 
    else:
       speed_progress=max(speed_progress_list)
       status = 'ok'
       message = json.dumps(message_list)
    #delete data
    for speed in speed_progress_list:
        sql = "delete from bi_progressstatus where speed_progress='%s'" %(speed)   
        cursor.execute(sql)
    return HttpResponse(json.dumps({"progressValue": speed_progress,"status":status,"message":message}))
@login_required
def hadoop_monitor(request):
    sql = "select parametervalues  from bi_sysparameter where sysparameter='cm_host'"
    cursor = connection.cursor()
    cursor.execute(sql)
    cm_host  = cursor.fetchall()[0][0]
    sql = "select parametervalues  from bi_sysparameter where sysparameter='cm_port'"
    cursor.execute(sql)
    cm_port  = cursor.fetchall()[0][0]
    sql = "select parametervalues  from bi_sysparameter where sysparameter='cm_username'"
    cursor.execute(sql)
    cm_username  = cursor.fetchall()[0][0]
    sql = "select parametervalues  from bi_sysparameter where sysparameter='cm_password'"
    cursor.execute(sql)
    cm_password  = cursor.fetchall()[0][0]
    from cm_api.api_client import ApiResource
    api = ApiResource(cm_host,cm_port,cm_username, cm_password)
    cdh5 = None
    serviceinfo=[]
    for c in api.get_all_clusters():
      if c.version == "CDH5":
         cdh5 = c
    for service in cdh5.get_all_services():
        temp_list=[]
        temp_list.append(service.name)
        temp_list.append(service.serviceState)
        temp_list.append(service.healthSummary)
        serviceinfo.append(temp_list) 
    cluster_name = cdh5.name
    return render_to_response('hadoop_monitor.html',{'cluster_name':cluster_name,'serviceinfo':serviceinfo})  
@login_required
def cognos_monitor(request):
    sql = "select system_name,deploy_contents,ip_address,HttpPort,concat(\"http://\",ip_address,\":\",HttpPort,\"/\",ContextRoot) as url from bi_resourceinfo where Flag='cognos'" 
    cursor = connection.cursor()
    cursor.execute(sql)
    result  = cursor.fetchall()
    cognos_list=[]
    for sig_cognos in result:
        templist = []
        system_name = sig_cognos[0]
        deploy_contents = sig_cognos[1]
        ip_address = sig_cognos[2]
        HttpPort = sig_cognos[3]
        url =  sig_cognos[4]
        check_status=JbossCheck(url)
        templist.append(system_name)
        templist.append(deploy_contents)
        templist.append(ip_address)
        templist.append(HttpPort) 
        templist.append(check_status)
        cognos_list.append(templist)
    return render_to_response('cognos_monitor.html',{'cognos_list':cognos_list})

@login_required
def usermanager(request):
    id = request.POST.getlist('choose')
    if id:
       cursor = connection.cursor()
       for myid in id:
          sql = "delete from auth_user where id =%s" %(myid) 
          cursor.execute(sql)  
       #返回
       sql = "select id from auth_user"
       cursor.execute(sql)
       id_tuple=cursor.fetchall()
       message_list=[]
       for myid in id:
          for all_id in id_tuple:
              if myid == all_id[0]:
                 message_list.append("fail")
              else:
                 message_list.append("ok") 
       if 'fail' in message_list:
           message="fail"
       else :
           message="ok"       
       return render_to_response('useradd_result.html',{'delete_message':message}) 
    else:
       user_list=User.objects.only('id','username','email')
       paginator = Paginator(user_list, int(10))
       defaultpage = 1
       page = request.GET.get('page')
       if page:
         userinfo = paginator.page(page)
       else:
         userinfo = paginator.page(defaultpage)
       return render_to_response('usermanager.html', {'userinfo': userinfo})
      
      #sql ="select id,username,telephone_number  from bi_system_user"
      #cursor = connection.cursor()
      #cursor.execute(sql)
      #result  = cursor.fetchall()
      #return render_to_response('usermanager.html',{'userinfo':result})

@login_required
def useradd(request):
    from UserEncryptDecrypt import set_password
    username=request.POST.get('username', '')
    passwd = request.POST.get('passwd', '')
    tel = request.POST.get('tel', '')  
    if username:
      import datetime
      mydate=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') 
      en_password = set_password(passwd) 
      sql  ="insert into auth_user (username,password,first_name,last_name,email,is_staff,is_active,is_superuser,last_login,date_joined) values('%s','%s','%s','%s','%s',1,1,1,'%s','%s')" %(username,en_password,username,username,tel,mydate,mydate)
      cursor = connection.cursor()
      cursor.execute(sql)
      sql ="select count(*) from auth_user where username = '%s'" %(username)
      cursor.execute(sql)
      counts = cursor.fetchall()[0][0] 
      if counts == 1:
         message = "ok"
      else:
         message = "fail"
      return render_to_response('useradd_result.html',{'message':message})
    else:
      sql = "select username from auth_user"
      cursor = connection.cursor()
      cursor.execute(sql)
      username = cursor.fetchall()   
      user_list=[]
      for user in username: 
        user_list.append(user[0])
      return render_to_response('useradd.html',{'username':json.dumps(user_list)})
@login_required
def usermod(request):
    from UserEncryptDecrypt import set_password
    id = request.POST.get('id',None)
    up_id = request.POST.get('userid',None)
    up_username = request.POST.get('username',None)
    up_passwd = request.POST.get('passwd',None)
    up_tel = request.POST.get('tel',None)  
    up_role_name = request.POST.get('role_name',None) 
    if up_id:
      new_password = set_password(up_passwd)
      sql ="update auth_user set username='%s',password='%s',email='%s' where id=%s" %(up_username,new_password,up_tel,up_id)
      cursor = connection.cursor()
      try:
        cursor.execute(sql)
        message="ok"
      except:
        message="fail"
      return render_to_response('useradd_result.html',{'update_message':message})
    if id:
      sql ="select id, username,password,email  from auth_user where id=%s" %(id)
      cursor = connection.cursor()
      cursor.execute(sql)
      userinfo  = cursor.fetchall()
      password_sql = "select password  from auth_user where id=%s" %(id)
      cursor.execute(password_sql)
      default_password = cursor.fetchall()[0][0]
      return render_to_response('usermod.html',{'userinfo':userinfo,'default_password':default_password})

from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from cms.bi.models import  Datasource
@login_required
def jdbc_get(request):
    export = request.POST.get('export') 
    fresh = request.POST.get('refresh')
    if export =='export':
       pattern = xlwt.Pattern() # Create the Pattern
       pattern.pattern = xlwt.Pattern.SOLID_PATTERN # May be: NO_PATTERN, SOLID_PATTERN, or 0x00 through 0x12
       pattern.pattern_fore_colour = 5 # May be: 8 through 63. 0 = Black, 1 = White, 2 = Red, 3 = Green, 4 = Blue, 5 = Yellow, 6 = Magenta, 7 = Cyan, 16 = Maroon, 17 = Dark Green, 18 = Dark Blue, 19 = Dark Yellow , almost brown), 20 = Dark Magenta, 21 = Teal, 22 = Light Gray, 23 = Dark Gray, the list goes on...
       borders = xlwt.Borders() 
       borders.left = xlwt.Borders.DASHED 
       borders.right = xlwt.Borders.DASHED
       borders.top = xlwt.Borders.DASHED
       borders.bottom = xlwt.Borders.DASHED
       borders.left_colour = 0x40
       borders.right_colour = 0x40
       borders.top_colour = 0x40
       borders.bottom_colour = 0x40
       style = xlwt.XFStyle() # Create Style
       style.borders = borders # Add Borders to Style
       style.pattern = pattern
       style0 = xlwt.easyxf('font: name Times New Roman, color-index red, bold on',num_format_str='#,##0.00')
       response = HttpResponse(mimetype='application/vnd.ms-excel')
       response['Content-Disposition'] = 'attachment;filename=datasource.xls'
       wb = xlwt.Workbook(encoding = 'utf-8')
       #第一列格式化
       sheet = wb.add_sheet(u'etl cognos数据源表')
       first_col = sheet.col(0)
       second_col=sheet.col(1)
       third_col =sheet.col(2)
       four_col =sheet.col(3)
       five_col =sheet.col(4)
       first_col.width = 170*20
       second_col.width=200*20
       third_col.width=400*20
       four_col.width=100*20
       five_col.width=150*20
       #1st line   
       sheet.write(0,0, '主机IP',style0)
       sheet.write(0,1, '连接串',style0)
       sheet.write(0,2, '数据库地址',style0)
       sheet.write(0,3, '端口',style0)
       sheet.write(0,4, '数据库名',style0)
       sheet.write(0,5, '属性',style0)
       row = 1
       for agencycustomer in Datasource.objects.all():
         sheet.write(row,0, agencycustomer.host_ip,style)
         sheet.write(row,1, agencycustomer.tns_name,style)
         sheet.write(row,2, agencycustomer.tns_host,style)
         sheet.write(row,3, agencycustomer.tns_port,style)
         sheet.write(row,4, agencycustomer.tns_service_name,style)
         sheet.write(row,5, agencycustomer.flag,style)
         row=row + 1
       import StringIO
       output = StringIO.StringIO()
       wb.save(output)
       output.seek(0)
       response.write(output.getvalue())
       return response
    if fresh:
        message_list = datasource_insert_database() 
        if 'fail' in message_list:
            message="fail"
        else:
            message="ok"
        return render_to_response('jdbc_get.html',{'message':message})
    else:
        contact_list=Datasource.objects.all()
        #contact_list = EtlJobInfo.objects.all()
        paginator = Paginator(contact_list, int(10)) 
        defaultpage = 1
        page = request.GET.get('page')
        if page:
          contacts = paginator.page(page)
        else:
          contacts = paginator.page(defaultpage) 
        return render_to_response('jdbc_get.html', {'contacts': contacts})
@login_required
def jdbc_get_search(request):
    if request.POST:
       search = request.POST.get('search')
    else:
       search = request.GET.get('search')
    jdbcinfo = Datasource.objects.filter(Q(host_ip__icontains=search)|Q(tns_host__icontains=search)|Q(tns_port__icontains=search)|Q(tns_service_name__icontains=search)|Q(flag__icontains=search))
    paginator = Paginator(jdbcinfo, int(10))
    defaultpage = 1
    page = request.GET.get('page')
    if page:
       jdbcinfos = paginator.page(page)
    else:
       jdbcinfos = paginator.page(defaultpage)
    return render_to_response('jdbc_get.html', {'jdbcinfos':jdbcinfos,'search':search})
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from cms.bi.models import  EtlJobInfo
@login_required
def etlinfo(request):
    export = request.POST.get('export') 
    fresh = request.POST.get('refresh')
    ref = request.POST.get('ref')
    if export =='export':
       pattern = xlwt.Pattern() # Create the Pattern
       pattern.pattern = xlwt.Pattern.SOLID_PATTERN # May be: NO_PATTERN, SOLID_PATTERN, or 0x00 through 0x12
       pattern.pattern_fore_colour = 5 # May be: 8 through 63. 0 = Black, 1 = White, 2 = Red, 3 = Green, 4 = Blue, 5 = Yellow, 6 = Magenta, 7 = Cyan, 16 = Maroon, 17 = Dark Green, 18 = Dark Blue, 19 = Dark Yellow , almost brown), 20 = Dark Magenta, 21 = Teal, 22 = Light Gray, 23 = Dark Gray, the list goes on...
       borders = xlwt.Borders() 
       borders.left = xlwt.Borders.DASHED 
       borders.right = xlwt.Borders.DASHED
       borders.top = xlwt.Borders.DASHED
       borders.bottom = xlwt.Borders.DASHED
       borders.left_colour = 0x40
       borders.right_colour = 0x40
       borders.top_colour = 0x40
       borders.bottom_colour = 0x40
       style = xlwt.XFStyle() # Create Style
       style.borders = borders # Add Borders to Style
       style.pattern = pattern
       style0 = xlwt.easyxf('font: name Times New Roman, color-index red, bold on',num_format_str='#,##0.00')
       response = HttpResponse(mimetype='application/vnd.ms-excel')
       response['Content-Disposition'] = 'attachment;filename=etl.xls'
       wb = xlwt.Workbook(encoding = 'utf-8')
       #第一列格式化
       sheet = wb.add_sheet(u'etl job参数对应表')
       second_col=sheet.col(1)
       third_col =sheet.col(2)
       four_col =sheet.col(3)
       five_col =sheet.col(4)
       second_col.width=200*20
       third_col.width=600*20
       four_col.width=650*20
       five_col.width=300*20
       #1st line   
       sheet.write(0,0, 'project',style0)
       sheet.write(0,1, 'job',style0)
       sheet.write(0,2, '参数',style0)
       sheet.write(0,3, '值',style0)
       sheet.write(0,4, '数据库ip',style0)
       sheet.write(0,5, '数据库端口',style0)
       sheet.write(0,6, '数据库名称',style0)
       row = 1
       for agencycustomer in EtlJobInfo.objects.all():
         sheet.write(row,0, agencycustomer.projectname,style)
         sheet.write(row,1, agencycustomer.jobname,style)
         sheet.write(row,2, agencycustomer.parameterkey,style)
         sheet.write(row,3, agencycustomer.parametervalue,style)
         sheet.write(row,4, agencycustomer.datasourceip,style)
         sheet.write(row,5, agencycustomer.datasourceport,style)
         sheet.write(row,6, agencycustomer.datasourcedb,style)
         row=row + 1
       import StringIO
       output = StringIO.StringIO()
       wb.save(output)
       output.seek(0)
       response.write(output.getvalue())
       return response
    if fresh:
        contact_list = EtlJobInfo.objects.all()
        paginator = Paginator(contact_list, int(10))
        defaultpage = 1
        page = request.GET.get('page')
        if page:
           contacts = paginator.page(page)
        else:
           contacts = paginator.page(defaultpage)
        return render_to_response('etlinfo.html', {'contacts': contacts})        
    if ref:
        contact_list = EtlJobInfo.objects.all()
        paginator = Paginator(contact_list, int(10))
        defaultpage = 1
        page = request.GET.get('page')
        if page:
          contacts = paginator.page(page)
        else:
          contacts = paginator.page(defaultpage)
        return render_to_response('etlinfo.html', {'contacts': contacts}) 
    else:
        contact_list = EtlJobInfo.objects.all()
        paginator = Paginator(contact_list, int(10)) 
        defaultpage = 1
        page = request.GET.get('page')
        if page:
          contacts = paginator.page(page)
        else:
          contacts = paginator.page(defaultpage) 
        return render_to_response('etlinfo.html', {'contacts': contacts})
@login_required
def etlinfo_search(request):
    if request.POST:
       search = request.POST.get('search')
    else:
       search = request.GET.get('search')
    etlinfo=EtlJobInfo.objects.filter(Q(projectname__icontains=search)|Q(jobname__icontains=search)|Q(parameterkey__icontains=search)|Q(parametervalue__icontains=search)|Q(datasourceip__icontains=search)|Q(datasourceport__icontains=search)|Q(datasourcedb__icontains=search))
    paginator = Paginator(etlinfo, int(10))
    defaultpage = 1
    page = request.GET.get('page')
    if page:
       etlinfos = paginator.page(page)
    else:
       etlinfos = paginator.page(defaultpage)
    return render_to_response('etlinfo.html', {'etlinfos':etlinfos,'search':search})
