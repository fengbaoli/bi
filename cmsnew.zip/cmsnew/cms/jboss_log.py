__author__ = '343715'
import paramiko

class JbossLog:
    def GetLogInfo(self,hostname,username,password,ssh_port,logspath):
        self.hostname = hostname
        self.username = username
        self.password = password
        self.ssh_port = ssh_port
        self.logspath = logspath
        self.ssh_str=self.hostname+"|||"+self.username+"|||"+self.password+"|||"+str(self.ssh_port)
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(self.hostname,self.ssh_port,self.username,self.password,timeout=20)
        log_path = self.logspath.split(",")
        results_list =[]
        for log in log_path:
            log1 = log.strip()
            format = "+%Y/%m/%d-%H:%M:%S"
            cmd = "ls -l --time-style \'%s\'  %s/*|awk '{print $5,$6,$7}'" %(format,log1)
            stdin,stdout,stderr = ssh.exec_command(cmd)
            results=stdout.read()
            results_list.append(results)
        ssh.close()
        log_info_list=[]
        for signle_log in results_list:
            signle_log_list= signle_log.split()
            total_sum = len(signle_log_list)-1
            size_start_num = 0
            createtime_start_num = 1
            path_start_num = 2
            while size_start_num <= total_sum:
               size = signle_log_list[size_start_num]
               createtime = signle_log_list[createtime_start_num]
               path = signle_log_list[path_start_num]
               filename = path.split("/")[-1]
               size_start_num = size_start_num +3
               createtime_start_num = createtime_start_num + 3
               path_start_num = path_start_num +3
               tuple = (self.ssh_str,filename,size,createtime,path)
               log_info_list.append(tuple)
        return   log_info_list
