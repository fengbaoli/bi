import sys
sys.path.append('/home/appman/pythonlib')
import MySQLdb
import datetime
import urllib2


time_sql = "select parametervalues from bi_sysparameter where sysparameter='keep_interval_time'"
conn=MySQLdb.connect(host="localhost",user="bi",passwd="bi",db="bi_manager",charset="utf8")
cursor = conn.cursor()
cursor.execute(time_sql)
result  = cursor.fetchall()
for mytime in result:
   sql ="delete    from bi_monitorjboss where monitor_date <date_sub(now(), interval %s minute)" %(str(mytime[0]))
cursor.execute(sql)
for mytime in result:
   sql ="delete    from bi_monitorcognos where monitor_date <date_sub(now(), interval %s minute)" %(str(mytime[0]))
cursor.execute(sql)
for mytime in result:
   sql ="delete    from bi_datasourcehistory where refresh_time <date_sub(now(), interval %s minute)" %(str(mytime[0]))
cursor.execute(sql)
cursor.close()
conn.close()
