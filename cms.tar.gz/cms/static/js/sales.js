﻿/**
 * Created by 343715 on 2016/8/24.
 */
/*获取cook*/
function getCookie(cookie_name)
{
   var allcookies = document.cookie;
   var cookie_pos = allcookies.indexOf(cookie_name);   //索引的长度
   // 如果找到了索引，就代表cookie存在，
   // 反之，就说明不存在。
if (cookie_pos != -1)
{
   // 把cookie_pos放在值的开始，只要给值加1即可。
   cookie_pos += cookie_name.length + 1;      //这里我自己试过，容易出问题，所以请大家参考的时候自己好好研究一下。。。
   var cookie_end = allcookies.indexOf(";", cookie_pos);
   if (cookie_end == -1)
   {
     cookie_end = allcookies.length;
   }
   var value = unescape(allcookies.substring(cookie_pos, cookie_end)); //这里就可以得到你想要的cookie的值了。。。
}
return value;
}



 /* vip查询选择*/
function openWin_vip_search() {
    var style = "width=700,height=600,location=no,directories=no,toolbar=no,status=no,menubar=no,resizable=no,scrollbars=no";
    window.open(/vip_search/,"打开窗口传值",style);
        }
/*子页面调用传值*/
function setValue_vipno(vip_card_no,vip_member_name,vip_type_name,vip_default_discount,vip_consumption_amount,accumulated_points,vip_member_tel_number) {
    document.getElementById("vip_card_no").value = vip_card_no;
    document.cookie = "vip_default_discount="+vip_default_discount;
    var i = table.rows.length;
    var startrow = 2;
    var total_amounts= 0;
    while(startrow < i )
    {
        var tb = document.getElementById('table');//获取表格名
        var discount = tb.rows[startrow].cells[5];
        var sale_price = tb.rows[startrow].cells[7];
        var sum_amounts = tb.rows[startrow].cells[8];
         /*重置折扣和价格及总价*/
        var  goods_price = tb.rows[startrow].cells[3].innerHTML
        var goods_quantites = tb.rows[startrow].cells[6].innerHTML
        discount.innerHTML = vip_default_discount;
        sale_price.innerHTML = parseFloat(goods_price)*vip_default_discount;
        sum_amounts.innerHTML = parseFloat(goods_price)*vip_default_discount*goods_quantites;
        total_amounts = parseFloat(total_amounts) + parseFloat(goods_price)*vip_default_discount*goods_quantites;
        startrow++;
    }
    /*更新总额*/
    var tb = document.getElementById('sum');
    tb.style.color= "red";
    var amounts =  tb.rows[0].cells[1];
    amounts.innerHTML = '总价:'+total_amounts;
    var real_sale_price = document.getElementById("real_sale_price");
    real_sale_price.innerHTML =total_amounts;
}

/*货物选择查询*/
function openWin_goods_search() {
    var style = "width=700,height=600,location=no,directories=no,toolbar=no,status=no,menubar=no,resizable=no,scrollbars=no";
    window.open(/good_search/, "打开窗口传值", style);
}



function setValue_goods(goods_no,goods_color,goods_size,goods_price,goods_discount,goods_quantity){
    var i = table.rows.length;
    var newTr = table.insertRow();
    /*去掉空格*/
    goods_quantity.replace(/\s/g, "")
    /*单位和数量分离*/
    var n = 0;
    while (n<goods_quantity.length) {
     var s="";
     while (goods_quantity.charCodeAt(n) < 256) {
     s=s+goods_quantity.charAt(n);
     n++;
    }
    var goods_quantites = s ;
    var s="";
     while (goods_quantity.charCodeAt(n) > 256) {
   s=s+goods_quantity.charAt(n);
   n++;
    }
    var goods_unit = s;
   }
    /*定义折扣*/
    var cookie_val = getCookie("vip_default_discount");
    if (typeof (cookie_val) == "undefined"){
        vip_discount= goods_discount;
    }
    else
    {
        vip_discount =  cookie_val;
    }

   /* 定义销售价钱和合计金额*/
    var sale_price = (parseFloat(vip_discount)*goods_price).toFixed(2);
    var sum_amounts =parseFloat(goods_quantites)*sale_price ;
    /*定义表格*/
    var newTd1 = newTr.insertCell();
    var newTd2 = newTr.insertCell();
    var newTd3 = newTr.insertCell();
    var newTd4 = newTr.insertCell();
    var newTd5 = newTr.insertCell();
    var newTd6 = newTr.insertCell();
    var newTd7 = newTr.insertCell();
    var newTd8 = newTr.insertCell();
    var newTd9 = newTr.insertCell();
    var newTd10 = newTr.insertCell();
    /*表格列绑定值*/
    newTd1.innerHTML = goods_no;
    newTd2.innerHTML = goods_color;
    newTd3.innerHTML = goods_size;
    newTd4.innerHTML = goods_price;
    newTd5.innerHTML = goods_unit;
    newTd6.innerHTML = vip_discount;
    newTd7.innerHTML =  goods_quantites;
    newTd8.innerHTML = sale_price;
    newTd9.innerHTML = sum_amounts;
    newTd10.innerHTML = null;
    /*表格添加onclick事件*/
    newTd1.onclick = function(){Modify_sale_values(goods_no,vip_discount,goods_quantites,sale_price,sum_amounts,goods_price)};
    newTd2.onclick = function(){Modify_sale_values(goods_no,vip_discount,goods_quantites,sale_price,sum_amounts,goods_price)};
    newTd3.onclick = function(){Modify_sale_values(goods_no,vip_discount,goods_quantites,sale_price,sum_amounts,goods_price)};
    newTd4.onclick = function(){Modify_sale_values(goods_no,vip_discount,goods_quantites,sale_price,sum_amounts,goods_price)};
    newTd5.onclick = function(){Modify_sale_values(goods_no,vip_discount,goods_quantites,sale_price,sum_amounts,goods_price)};
    newTd6.onclick = function(){Modify_sale_values(goods_no,vip_discount,goods_quantites,sale_price,sum_amounts,goods_price)};
    newTd7.onclick =  function(){Modify_sale_values(goods_no,vip_discount,goods_quantites,sale_price,sum_amounts,goods_price)};
    newTd8.onclick = function(){Modify_sale_values(goods_no,vip_discount,goods_quantites,sale_price,sum_amounts,goods_price)};
    newTd9.onclick = function(){Modify_sale_values(goods_no,vip_discount,goods_quantites,sale_price,sum_amounts,goods_price)};
    newTd10.onclick = function(){Modify_sale_values(goods_no,vip_discount,goods_quantites,sale_price,sum_amounts,goods_price)};
    /*cook 数量及商品编号*/
    /*插入总数和总金额*/
    var table_total = table.rows.length;
    var startrow = 2;
    var total_goods_quantites=0;
    var total_amounts=0;
    var total_good_price =0;
    while(startrow < table_total )
    {
        var tb = document.getElementById('table');//获取表格名
        var goods_quantites = tb.rows[startrow].cells[6].innerHTML;
        var sum_amounts = tb.rows[startrow].cells[8].innerHTML;
        var good_price= tb.rows[startrow].cells[3].innerHTML;
        total_goods_quantites = parseFloat(total_goods_quantites)+parseFloat(goods_quantites);
        total_amounts = parseFloat(total_amounts)+ parseFloat(sum_amounts);
        var row_good_price = parseFloat(good_price)*parseFloat(goods_quantites);
        total_good_price = total_good_price + row_good_price;
        startrow++;
    }
    /*插入前更新*/
    var t1=document.getElementById("sum");
    t1.style.color= "red";
    t1.style.fontWeight= "bold";
    t1.style.fontSize= "20px";
    var rowNum=t1.rows.length;
    if(rowNum>0)
    {
         for(i=0;i<rowNum;i++)
             {
                 t1.deleteRow(i);
                 rowNum=rowNum-1;
                 i=i-1;
              }
    }

    var sumtr = sum.insertRow();
    var sumtr1 = sumtr.insertCell();
    var sumtr2 = sumtr.insertCell();
    sumtr1.innerHTML ="数量:"+total_goods_quantites;
    sumtr2.innerHTML = "总价:"+total_amounts;

    /*更新底脚的数量，总价及原价值*/
    var real_sale_price = document.getElementById("real_sale_price");
    var final_quantites = document.getElementById("final_quantites");
    var original_price = document.getElementById("original_price");
    real_sale_price.innerHTML =total_amounts;
    final_quantites.innerHTML =total_goods_quantites;
    original_price.innerHTML =total_good_price;

    /*test*/
    /*提交到后台处理表单*/
    /*
    var addinput = document.createElement('input');
    addinput.setAttribute('type', 'hidden');
    */

}

        function setValue(name,password) {
             var i =tab1.rows.length;
             var Nam="'div1'";
             var Cod="fuJ"+i;
             var newTr = tab1.insertRow();
             var newTd1 = newTr.insertCell();
             var newTd2 = newTr.insertCell();
             newTd1.innerHTML = name;
             newTd2.innerHTML = password;
            var addinput = document.createElement('input');  //创建input节点
            addinput.setAttribute('type', 'hidden');//定义类型是文本输入
            addinput.value = name;
            addinput.name = "username"
            document.getElementById('form').appendChild(addinput ); //添加到form中显示

        }

/*时钟*/
function setTime(){
    var day="";
    var month="";
    var ampm="";
    var ampmhour="";
    var myweekday="";
    var year="";
    var myHours="";
    var myMinutes="";
    var mySeconds="";
    mydate=new Date();
    myweekday=mydate.getDay();
    mymonth=parseInt(mydate.getMonth()+1)<10?"0"+(mydate.getMonth()+1):mydate.getMonth()+1;
    myday= mydate.getDate();
    myyear= mydate.getYear();
    myHours = mydate.getHours();
    myMinutes = mydate.getMinutes();
    mySeconds = parseInt(mydate.getSeconds())<10?"0"+mydate.getSeconds():mydate.getSeconds();
    year=(myyear > 200) ? myyear : 1900 + myyear;
    datetime.innerText=year+"-"+mymonth+"-"+myday+"  "+myHours+":"+myMinutes+":"+mySeconds;  setTimeout("setTime()",1000);
}

/*货物传值给父节点*/
function Ajaxsend(goods_no,goods_quantity){
    var xmlhttp;
    if (window.XMLHttpRequest)
      {
          // code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
      }
    else
      {
          // code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
      }
    xmlhttp.open("POST","/sales_management/",true);
    xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    xmlhttp.send("goods_no="+goods_no+"&goods_quantity="+goods_quantity);
}

function selectedThis_goods(obj) {
    var goods = obj.title.split(" ");
    var goods_no = goods[0]
    var goods_color = goods[1]
    var goods_size = goods[2]
    var goods_price = goods[3]
    var goods_discount = goods[4]
    var goods_quantity = goods[5]
    var num= goods_quantity.replace(/[^0-9]/ig,"")
    window.opener.setValue_goods(goods_no,goods_color,goods_size,goods_price,goods_discount,goods_quantity);//调用父窗口的方法进行传值
    window.opener.Ajaxsend(goods_no,goods_quantity)
    window.opener = null;
    window.close();
    /*
    if (num == 0){
        alert("error")
    }
    else{
    window.opener.setValue_goods(goods_no,goods_color,goods_size,goods_price,goods_discount,goods_quantity);//调用父窗口的方法进行传值
    window.opener.Ajaxsend(goods_no,goods_quantity)
    window.opener = null;
    window.close();
    }
    */
}


/*vip传值给父节点*/
function selectedThis_vips(obj){
    var vips = obj.title.split(" ");
    var vip_card_no = vips[0]
    var vip_member_name = vips[1]
    var vip_type_name  = vips[2]
    var vip_default_discount = vips[3]
    var vip_consumption_amount = vips[4]
    var accumulated_points = vips[5]
    var vip_member_tel_number = vips[6]
    window.opener.setValue_vipno(vip_card_no,vip_member_name,vip_type_name,vip_default_discount,vip_consumption_amount,accumulated_points,vip_member_tel_number);//调用父窗口的方法进行传值
    window.opener = null;
    window.close();
}


/*刷新页面，重置预销售数量为0*/
function Reset_sale(){
    var xmlhttp;
    var resetglag=0
    if (window.XMLHttpRequest)
      {
          // code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
      }
    else
      {
          // code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
      }
    xmlhttp.open("POST","/sales_management/",true);
    xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    xmlhttp.send("reset="+resetglag);
}




function Modify_sale_values(goods_no,vip_discount,goods_quantites,sale_price,sum_amounts,goods_price)
{
    var iHeight =300 ;
    var iWidth = 400;
    var iTop = (window.screen.height-30-iHeight)/2; //获得窗口的垂直位置;
    var iLeft = (window.screen.width-10-iWidth)/2; //获得窗口的水平位置;
    var td = event.srcElement;
    var row_number = td.parentElement.rowIndex + 1
    window.open("/good_sale_modify/?goods_no="+goods_no+","+"vip_discount="+vip_discount+","+"goods_quantites="+goods_quantites+","+"sale_price="+sale_price+","+"sum_amounts="+sum_amounts+","+"goods_price="+goods_price+","+"row_number="+row_number,"销售货物修改",'height='+iHeight+',,innerHeight='+iHeight+',width='+iWidth+',innerWidth='+iWidth+',top='+iTop+',left='+iLeft+',toolbar=no,menubar=no,scrollbars=auto,resizeable=no,location=no,status=no')
}





function set_sale_modify_value(goods_no,goods_quantites,good_sale_price,goods_discount,sum_amounts,goods_mark,row_number){
    var goods_no =  goods_no;
    var goods_quantites = goods_quantites;
    var good_sale_price = good_sale_price;
    var goods_discount  = goods_discount;
    var sum_amounts = sum_amounts;
    var goods_mark = goods_mark;
    var row_number = row_number-1;   //之前点击表格行数
    var tb = document.getElementById('table');//获取表格名
    var discount = tb.rows[row_number].cells[5];
    var quantites = tb.rows[row_number].cells[6];
    var sale_price = tb.rows[row_number].cells[7];
    var total_amount= tb.rows[row_number].cells[8];
    var mark =  tb.rows[row_number].cells[9];
    discount.innerHTML = goods_discount;
    quantites.innerHTML = goods_quantites;
    sale_price.innerHTML = good_sale_price;
    total_amount.innerHTML = sum_amounts;
    mark.innerHTML =  goods_mark;
}



