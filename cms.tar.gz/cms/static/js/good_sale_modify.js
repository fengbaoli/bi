/**
 * Created by 343715 on 2016/9/10.
 */
 function goods_mod_submit(){
        var goods_no_id = document.getElementById('goods_no')
        var goods_quantites_id =  document.getElementById('goods_quantites');
        var good_sale_price_id = document.getElementById('good_sale_price');
        var goods_discount_id = document.getElementById('goods_discount');
        var sum_amounts_id =  document.getElementById('sum_amounts');
        var goods_mark_id = document.getElementById('goods_mark');
        var row_number_id = document.getElementById('rows_number');
        var goods_no = goods_no_id.value;
        var goods_quantites = goods_quantites_id.value;
        var good_sale_price = good_sale_price_id.value;
        var goods_discount = goods_discount_id.value;
        var sum_amounts = sum_amounts_id.value;
        var goods_mark = goods_mark_id.value;
        var row_number = row_number_id.value;
        window.opener.set_sale_modify_value(goods_no,goods_quantites,good_sale_price,goods_discount,sum_amounts,goods_mark,row_number)
        window.opener = null;
        window.close();
    }
    function get_parent_values(){
     /*��ȡ���ڵ�openѡ��Ļ�ȡ��ֵ*/
    var url=location.href.split("?")[1];
     /*�зֻ�ȡ����ֵ*/
    var goods_no=url.split(",")[0].split("=")[1]
    var goods_discount=url.split(",")[1].split("=")[1]
    var goods_quantites=url.split(",")[2].split("=")[1]
    var good_sale_price=url.split(",")[3].split("=")[1]
    var sum_amounts=url.split(",")[4].split("=")[1]
    var goods_price=url.split(",")[5].split("=")[1]
    var row_number = url.split(",")[6].split("=")[1]
     /*ͨ��Ԫ�ص�id����input�ĳ�ʼֵvalue*/
    document.getElementById('goods_no').value = goods_no;
    document.getElementById('goods_discount').value = goods_discount;
    document.getElementById('goods_quantites').value = goods_quantites;
    document.getElementById('good_sale_price').value = good_sale_price;
    document.getElementById('sum_amounts').value = sum_amounts;
    document.getElementById('rows_number').value = row_number;
    return goods_price
    }

    function goods_mod_close(){
        window.opener = null;
        window.close();
    }
    function  mod_goods_quantites(){
        var goods_quantites_id =  document.getElementById('goods_quantites');
        var good_sale_price_id = document.getElementById('good_sale_price');
        var goods_discount_id = document.getElementById('goods_discount');
        var sum_amounts_id =  document.getElementById('sum_amounts');
        var goods_quantites = goods_quantites_id.value;
        var good_sale_price = good_sale_price_id.value;
        var goods_price = get_parent_values();
        var goods_discount = goods_discount_id.value;
        var sum_amounts = sum_amounts_id.value;
        goods_quantites_id.value = parseInt(goods_quantites);
        sum_amounts_id.value = (goods_quantites * goods_price * goods_discount).toFixed(2);

    }

    function  mod_goods_sale_price(){
        var goods_quantites_id =  document.getElementById('goods_quantites');
        var good_sale_price_id = document.getElementById('good_sale_price');
        var goods_discount_id = document.getElementById('goods_discount');
        var sum_amounts_id =  document.getElementById('sum_amounts');
        var goods_quantites = goods_quantites_id.value;
        var good_sale_price = good_sale_price_id.value;
        var goods_price = get_parent_values();
        var goods_discount = goods_discount_id.value;
        var sum_amounts = sum_amounts_id.value;
        good_sale_price_id.value = good_sale_price;
        goods_discount_id.value = (good_sale_price/goods_price).toFixed(2);
        sum_amounts_id.value = (good_sale_price * goods_quantites).toFixed(2);
        goods_quantites_id.value = parseInt(goods_quantites);

    }
    function  mod_goods_discount(){
        var goods_quantites_id =  document.getElementById('goods_quantites');
        var good_sale_price_id = document.getElementById('good_sale_price');
        var goods_discount_id = document.getElementById('goods_discount');
        var sum_amounts_id =  document.getElementById('sum_amounts');
        var goods_quantites = goods_quantites_id.value;
        var good_sale_price = good_sale_price_id.value;
        var goods_price = get_parent_values();
        var goods_discount = goods_discount_id.value;
        var sum_amounts = sum_amounts_id.value;
    }
    function  mod_sum_amounts(){
        var goods_quantites_id =  document.getElementById('goods_quantites');
        var good_sale_price_id = document.getElementById('good_sale_price');
        var goods_discount_id = document.getElementById('goods_discount');
        var sum_amounts_id =  document.getElementById('sum_amounts');
        var goods_quantites = goods_quantites_id.value;
        var good_sale_price = good_sale_price_id.value;
        var goods_price = get_parent_values();
        var goods_discount = goods_discount_id.value;
        var sum_amounts = sum_amounts_id.value;
        sum_amounts_id.value = sum_amounts;
        good_sale_price_id.value = (sum_amounts/goods_quantites).toFixed(2)
        goods_discount_id.value = ((sum_amounts/goods_quantites)/goods_price).toFixed(2)
    }
