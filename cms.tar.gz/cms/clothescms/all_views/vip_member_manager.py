# -*- coding: utf-8 -*-
from django.shortcuts import  render_to_response
from  django.http import HttpResponse
from django.http import  HttpResponseRedirect
from cms.clothescms.models import System_user,User_role,Customer,Seasonal,Brand,Color,Size
from cms.clothescms.models import  Unit,Vip,Category,Vip_member
from django.db import connection,transaction
from django.contrib.auth.decorators import login_required
from django.contrib.sessions.models import Session
import MySQLdb
import MySQLdb.cursors
import  time

def vip_member_management(request):
    title_sql="select vip_card_no,vip_member_name,vip_type_name,vip_member_tel_number,vip_consumption_amount,accumulated_points,recent_consumption,open_date_card,years_birthday,mark from  clothescms_vip_member"
    cursor = connection.cursor()
    cursor.execute(title_sql)
    result  = cursor.fetchall()
    return render_to_response('vip_member_management.html',{'vips':result})
def add_vip_member(request):
    #获取vip所有类别
    vip_type_name= Vip.objects.all()
    #vip卡号生成
    vip_card_no="mao-"+str("%0.3f" % float(time.time())).replace(".","")
    return render_to_response('add_vip_member.html',{'vip_type_name':vip_type_name,'vip_card_no':vip_card_no})
def addvip_member_result(request):
    vip_card_no = request.POST.get('vip_card_no',None)
    vip_member_name = request.POST.get('vip_member_name',None)
    vip_type_name = request.POST.get('vip_type_name',None)
    vip_member_tel_number = request.POST.get('vip_member_tel_number',None)
    years_birthday = request.POST.get('years_birthday',None)
    mark = request.POST.get('mark',None)

    if  Vip_member.objects.filter(vip_card_no = vip_card_no):
        message = "卡号已经存在"
        return render_to_response('vip_member_err.html',{'message':message})
    else:
        import datetime,time
        #获取当前年份
        this_year= time.strftime('%Y',time.localtime(time.time()))
        #对输入的vip生日格式化为月日
        vip_member_birthday= time.strftime('%m-%d',time.strptime(years_birthday,'%Y-%m-%d'))
        #拼接得到vip当年生日
        years_birthday = this_year+"-"+vip_member_birthday
        #格式化vip当年生日
        years_birthday= time.strftime('%Y-%m-%d',time.strptime(years_birthday,'%Y-%m-%d'))
        #消费金额初始化
        vip_consumption_amount="0"
        #累计积分初始化
        accumulated_points="0"
        #最近消费日期初始化
        recent_consumption=time.strftime('%Y-%m-%d',time.localtime(time.time()))
        #开卡日期初始化
        open_date_card=time.strftime('%Y-%m-%d',time.localtime(time.time()))
        new_vip_member= Vip_member(vip_card_no=vip_card_no,vip_member_name=vip_member_name,vip_type_name =vip_type_name ,vip_member_tel_number = vip_member_tel_number,vip_consumption_amount = vip_consumption_amount,accumulated_points =  accumulated_points ,recent_consumption = recent_consumption,open_date_card = open_date_card,years_birthday = years_birthday,mark = mark)
        new_vip_member.save()
        message = "新增VIP成功"
        title_sql="select vip_card_no,vip_member_name,vip_type_name,vip_member_tel_number,vip_consumption_amount,accumulated_points,recent_consumption,open_date_card,years_birthday,mark from  clothescms_vip_member"
        cursor = connection.cursor()
        cursor.execute(title_sql)
        result  = cursor.fetchall()
        return render_to_response('vip_member_management.html',{'message':message,'vips':result})

def edit_vip_member(request):
    title_sql="select vip_card_no,vip_member_name,vip_type_name,vip_member_tel_number,vip_consumption_amount,accumulated_points,recent_consumption,open_date_card,years_birthday,mark from  clothescms_vip_member"
    cursor = connection.cursor()
    cursor.execute(title_sql)
    result  = cursor.fetchall()
    return render_to_response('edit_vip_member.html',{'vips':result})
def delvip_member(request):
    values = request.POST.getlist('vip_card_no')
    #删除数据库数据
    for vip_card_no in values:
        p = Vip_member.objects.get(vip_card_no=vip_card_no)
        p.delete()
    title_sql="select vip_card_no,vip_member_name,vip_type_name,vip_member_tel_number,vip_consumption_amount,accumulated_points,recent_consumption,open_date_card,years_birthday,mark from  clothescms_vip_member"
    cursor = connection.cursor()
    cursor.execute(title_sql)
    result  = cursor.fetchall()
    return render_to_response('vip_member_management.html',{'vips':result})


def mod_vip_member(request):
    vip_card_no = request.POST.get('vip_card_no',None)
    title_sql="select vip_card_no,vip_member_name,vip_type_name,vip_member_tel_number,vip_consumption_amount,accumulated_points,recent_consumption,open_date_card,years_birthday,mark from  clothescms_vip_member where vip_card_no=%s" %(vip_card_no)
    cursor = connection.cursor()
    cursor.execute(title_sql)
    result  = cursor.fetchall()
    vip_type_name= Vip.objects.all()
    return render_to_response('mod_vip_member.html',{'vips':result,'vip_types':vip_type_name})

def modvip_member_result(request):
    vip_card_no = request.POST.get('vip_card_no',None)
    vip_member_name = request.POST.get('vip_member_name',None)
    vip_type_name = request.POST.get('vip_type_name',None)
    vip_member_tel_number = request.POST.get('vip_member_tel_number',None)
    vip_consumption_amount =request.POST.get('vip_consumption_amount',None)
    accumulated_points =request.POST.get('accumulated_points',None)
    recent_consumption =request.POST.get('recent_consumption',None)
    open_date_card =request.POST.get('open_date_card',None)
    years_birthday =request.POST.get('years_birthday',None)
    mark =request.POST.get('vip_member_tel_number',None)
    #更新
    Vip_member.objects.filter(vip_card_no=vip_card_no).update(
	vip_member_name=vip_member_name,
	vip_type_name=vip_type_name,
	vip_member_tel_number=vip_member_tel_number,
	vip_consumption_amount=vip_consumption_amount,
	accumulated_points=accumulated_points,
	recent_consumption=recent_consumption,
	open_date_card = open_date_card,
	years_birthday = years_birthday,
	mark = mark)
    title_sql="select vip_card_no,vip_member_name,vip_type_name,vip_member_tel_number,vip_consumption_amount,accumulated_points,recent_consumption,open_date_card,years_birthday,mark from  clothescms_vip_member"
    cursor = connection.cursor()
    cursor.execute(title_sql)
    result  = cursor.fetchall()
    return render_to_response('vip_member_management.html',{'vips':result})




