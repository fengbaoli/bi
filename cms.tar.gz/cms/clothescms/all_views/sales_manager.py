# -*- coding: utf-8 -*-
from django.shortcuts import  render_to_response
from  django.http import HttpResponse
from django.http import  HttpResponseRedirect
from cms.clothescms.models import System_user,User_role,Customer,Seasonal,Brand,Color,Size
from cms.clothescms.models import  Unit,Vip,Category,Vip_member,Goods
from django.db import connection,transaction
from django.contrib.auth.decorators import login_required
from django.contrib.sessions.models import Session
import MySQLdb
import MySQLdb.cursors
import  datetime,time
import re


def sales_management(request):
    if request.POST:
        goods_no_input = request.POST.get("goods_no",None)
        goods_quantity_input = request.POST.get("goods_quantity",None)
        resetglag =  request.POST.get("reset",None)
        if not goods_no_input is None and not goods_quantity_input is None and resetglag is None:
            #查找库存货物单位及数量
            sql = "select  goods_quantity,db_goods_sale_quantity_temp   from clothescms_goods where goods_no = %s" % (goods_no_input)
            cursor = connection.cursor()
            cursor.execute(sql)
            result  = cursor.fetchall()
            db_goods_sale_quantity_temp = result[0][1]
            #将库存查询结果分离为数量和单位
            for i in re.findall(r"\d+",result[0][0]):
                total_goods_quantity = i
            goods_unit = re.sub(r'([\d]+)','',result[0][0])
            #从选择的货物中提取出货物数量
            for n in re.findall(r"\d+",goods_quantity_input):
                select_sale_goods_quantity = n
            '''
            #total_goods_quantity为数据库货物的库存量（不包含单位）
            #goods_unit为数据库货物的单位
            #select_sale_goods_quantity为选择准备售卖的数量
            #db_goods_sale_quantity_temp为数据库中准备售卖的数量
        '''
            db_goods_sale_quantity_temp = str(db_goods_sale_quantity_temp)+goods_unit
            #进行数据库数据更新，更新字段goods_sale_quantity（准备售出的数量）
            usql = "update  clothescms_goods set  db_goods_sale_quantity_temp = db_goods_sale_quantity_temp + '%s' where goods_no = '%s'" %(select_sale_goods_quantity,goods_no_input)
            cursor = connection.cursor()
            cursor.execute(usql)
            #当前日期
            now_date=time.strftime('%Y-%m-%d',time.localtime(time.time()))
            #单据号
            bill_number="XS"+str("%0.3f" % float(time.time())).replace(".","")
            #营业员
            users = System_user.objects.all()
            #vip卡号及vip姓名
            title_sql="select vip_card_no,vip_member_name from clothescms_vip_member"
            cursor = connection.cursor()
            cursor.execute(title_sql)
            vips  = cursor.fetchall()
            return  render_to_response("sales_manager.html",{'now_date':now_date,'bill_number':bill_number,'users':users})
        elif int(resetglag) == 0:
            #刷新页面，重置预销售数量为0
            sql = "update clothescms_goods set db_goods_sale_quantity_temp=0"
            cursor = connection.cursor()
            cursor.execute(sql)
            #当前日期
            now_date=time.strftime('%Y-%m-%d',time.localtime(time.time()))
            #单据号
            bill_number="XS"+str("%0.3f" % float(time.time())).replace(".","")
            #营业员
            users = System_user.objects.all()
            #vip卡号及vip姓名
            title_sql="select vip_card_no,vip_member_name from clothescms_vip_member"
            cursor = connection.cursor()
            cursor.execute(title_sql)
            vips  = cursor.fetchall()
            return  render_to_response("sales_manager.html",{'now_date':now_date,'bill_number':bill_number,'users':users})
        else:
            #当前日期
            now_date=time.strftime('%Y-%m-%d',time.localtime(time.time()))
            #单据号
            bill_number="XS"+str("%0.3f" % float(time.time())).replace(".","")
            #营业员
            users = System_user.objects.all()
            #vip卡号及vip姓名
            title_sql="select vip_card_no,vip_member_name from clothescms_vip_member"
            cursor = connection.cursor()
            cursor.execute(title_sql)
            vips  = cursor.fetchall()
            return  render_to_response("sales_manager.html",{'now_date':now_date,'bill_number':bill_number,'users':users})
    else:
        #当前日期
        now_date=time.strftime('%Y-%m-%d',time.localtime(time.time()))
        #单据号
        bill_number="XS"+str("%0.3f" % float(time.time())).replace(".","")
        #营业员
        users = System_user.objects.all()
        #vip卡号及vip姓名
        title_sql="select vip_card_no,vip_member_name from clothescms_vip_member"
        cursor = connection.cursor()
        cursor.execute(title_sql)
        vips  = cursor.fetchall()
        return  render_to_response("sales_manager.html",{'now_date':now_date,'bill_number':bill_number,'users':users})

def vip_search(request):
    #如果进行vip筛选进行模糊查询匹配
    if  request.POST:
        import sys;
        reload(sys);
        sys.setdefaultencoding("utf8")
        vip_name =  request.POST.get('vip_name',None)
        #vip卡号及vip姓名
        sql_vip_name ='%'+vip_name+'%'
        sql = "select b.vip_card_no,b.vip_member_name,b.vip_type_name,a.vip_default_discount,b.vip_consumption_amount,b.accumulated_points,b.vip_member_tel_number  from clothescms_vip a , clothescms_vip_member b where a.vip_type_name = b.vip_type_name and  b.vip_member_name like '%%%s%%'" % (sql_vip_name)
        cursor = connection.cursor()
        cursor.execute(sql)
        result  = cursor.fetchall()
        #result = Vip_member.objects.filter(vip_member_name__icontains = vip_name)
        return render_to_response('vip_search.html',{'vip_search_result':result})
    #如果没有模糊查询，直接全部列表展示结果
    else:
        sql = "select b.vip_card_no,b.vip_member_name,b.vip_type_name,a.vip_default_discount,b.vip_consumption_amount,b.accumulated_points,b.vip_member_tel_number  from clothescms_vip a , clothescms_vip_member b where a.vip_type_name = b.vip_type_name"
        cursor = connection.cursor()
        cursor.execute(sql)
        result  = cursor.fetchall()
        #result = Vip_member.objects.all()
        return render_to_response('vip_search.html',{'vip_search_result':result})

def good_search(request):
    if  request.POST:
        import sys
        reload(sys)
        sys.setdefaultencoding("utf8")
        goods_no =  request.POST.get('goods_no',None)
        sql_goods_no ='%'+goods_no+'%'
        sql = "select goods_no,goods_color,goods_size,goods_price,goods_discount,concat(goods_quantity-db_goods_sale_quantity_temp,substring(goods_quantity, -1)) from clothescms_goods where  goods_no like '%%%s%%'"  % (sql_goods_no)
        cursor = connection.cursor()
        cursor.execute(sql)
        result = cursor.fetchall()
        return render_to_response('good_search.html',{'goods':result})
    else:
        sql = "select goods_no,goods_color,goods_size,goods_price,goods_discount,concat(goods_quantity-db_goods_sale_quantity_temp,substring(goods_quantity, -1)) from clothescms_goods where goods_quantity-db_goods_sale_quantity_temp !=0"
        cursor = connection.cursor()
        cursor.execute(sql)
        result = cursor.fetchall()
        return render_to_response('good_search.html',{'goods':result})


def good_sale_modify(request):
    if request.POST:
        goods_no =  request.POST.get("goods_no")


    goods_no =  "test"
    #return  render_to_response('good_sale_modify.html',{'goods_no':goods_no})
    #goods_no =  request.POST.get("goods_no")
    #print("testsssssw")
    #print(goods_no)
    #goods_no = goods_no.encode("utf-8")


    #goods_quantites = request.POST.get("goods_quantites",None).encode("utf-8")

    return render_to_response('good_sale_modify.html',{'goods_no':goods_no})